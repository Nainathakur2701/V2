@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title The Cream Studio POS - Install Libraries

if exist ".venv\Scripts\python.exe" goto INSTALL
where py >nul 2>nul
if not errorlevel 1 (
  py -3 -m venv .venv
  if errorlevel 1 goto VENV_FAILED
  goto INSTALL
)
where python >nul 2>nul
if not errorlevel 1 (
  python -m venv .venv
  if errorlevel 1 goto VENV_FAILED
  goto INSTALL
)
echo Python 3 was not found. Install Python 3.11 or 3.12 from https://www.python.org/downloads/windows/
echo Tick "Add python.exe to PATH" during installation.
pause
exit /b 1

:INSTALL
echo Installing POS libraries into the app's private .venv folder...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto FAILED
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto FAILED
echo.
echo Installation complete. Run START_POS.bat to open the POS.
echo For scanned-image/PDF OCR, Tesseract OCR for Windows must be installed separately.
pause
exit /b 0

:VENV_FAILED
echo Could not create the app's Python environment. Repair or reinstall Python 3 and try again.
pause
exit /b 1

:FAILED
echo Library installation failed. Check internet access and retry.
pause
exit /b 1
