@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title The Cream Studio POS - Faster Startup

rem Use a local virtual environment so Windows/global Python changes do not affect this app.
if exist ".venv\Scripts\python.exe" goto RUN_POS

set "PY_LAUNCHER="
where py >nul 2>nul
if not errorlevel 1 set "PY_LAUNCHER=py -3"
if defined PY_LAUNCHER goto CREATE_VENV
where python >nul 2>nul
if not errorlevel 1 set "PY_LAUNCHER=python"
if defined PY_LAUNCHER goto CREATE_VENV

echo.
echo Python 3 was not found on this Windows PC.
echo Install Python 3.11 or 3.12 from https://www.python.org/downloads/windows/
echo During setup, tick "Add python.exe to PATH", then run START_POS.bat again.
echo Your saved tcs_pos.db data has not been changed.
pause
exit /b 1

:CREATE_VENV
echo Creating a private Python environment for this POS...
%PY_LAUNCHER% -m venv .venv
if errorlevel 1 (
  echo Could not create the local Python environment.
  echo Try reinstalling Python and enable the Python Launcher / PATH option.
  pause
  exit /b 1
)
echo Installing POS libraries. This may take a few minutes and needs internet access.
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto INSTALL_FAILED
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto INSTALL_FAILED

:RUN_POS
echo Starting The Cream Studio POS...
".venv\Scripts\python.exe" server.py
if errorlevel 1 (
  echo.
  echo POS stopped with an error. Read the error above before trying again.
  echo Your database is stored locally in this folder as tcs_pos.db.
  pause
)
exit /b

:INSTALL_FAILED
echo.
echo Library installation failed. Check internet access and run START_POS.bat again.
echo Your existing tcs_pos.db has not been deleted or replaced.
pause
exit /b 1
