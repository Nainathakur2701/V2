#!/usr/bin/env python3
"""Create a consistent backup of TCS POS data and essential application files."""
from __future__ import annotations
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent
DB = ROOT / "tcs_pos.db"
BACKUP_DIR = ROOT / "backups"
CORE_FILES = [
    "server.py", "catalog_source.py", "index.html", "logo.png",
    "requirements.txt", "README.txt", "START_POS.bat",
    "INSTALL_REQUIREMENTS.bat", "backup_pos.py", "BACKUP_POS.bat",
]

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def main() -> int:
    if not DB.is_file():
        print("ERROR: tcs_pos.db was not found beside server.py.")
        print("Run BACKUP_POS.bat from your active TCS_POS_V6 software folder.")
        print("No database was created or changed.")
        return 2

    BACKUP_DIR.mkdir(exist_ok=True)
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    out = BACKUP_DIR / f"TCS_POS_FULL_BACKUP_{stamp}.zip"
    with tempfile.TemporaryDirectory(prefix="tcs_pos_backup_") as td:
        snapshot = Path(td) / "tcs_pos.db"
        # SQLite's backup API captures a consistent snapshot, including committed WAL data.
        with sqlite3.connect(f"file:{DB.as_posix()}?mode=ro", uri=True, timeout=30) as source:
            with sqlite3.connect(snapshot) as dest:
                source.backup(dest)
                check = dest.execute("PRAGMA integrity_check").fetchone()[0]
                if check != "ok":
                    print(f"ERROR: database integrity check failed: {check}")
                    return 3

        manifest = {
            "created_at_local": dt.datetime.now().astimezone().isoformat(timespec="seconds"),
            "application": "The Cream Studio POS",
            "database_file": "tcs_pos.db",
            "database_integrity_check": "ok",
            "note": "Consistent SQLite snapshot; includes committed WAL data. Restore only while POS is closed.",
            "files": {}
        }
        with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            z.write(snapshot, "tcs_pos.db")
            manifest["files"]["tcs_pos.db"] = {
                "size_bytes": snapshot.stat().st_size,
                "sha256": sha256(snapshot)
            }
            for name in CORE_FILES:
                path = ROOT / name
                if path.is_file() and name != "tcs_pos.db":
                    arcname = name
                    z.write(path, arcname)
                    manifest["files"][arcname] = {
                        "size_bytes": path.stat().st_size,
                        "sha256": sha256(path)
                    }
            # Preserve optional app-owned data folders if present, excluding virtual environments/backups.
            for folder_name in ("uploads", "exports", "attachments", "data"):
                folder = ROOT / folder_name
                if folder.is_dir():
                    for path in folder.rglob("*"):
                        if path.is_file():
                            arcname = path.relative_to(ROOT).as_posix()
                            z.write(path, arcname)
                            manifest["files"][arcname] = {
                                "size_bytes": path.stat().st_size,
                                "sha256": sha256(path)
                            }
            z.writestr("backup_manifest.json", json.dumps(manifest, indent=2, ensure_ascii=False))

    # Verify the archive opens and the database snapshot passes integrity check.
    with zipfile.ZipFile(out, "r") as z:
        bad = z.testzip()
        if bad:
            out.unlink(missing_ok=True)
            print(f"ERROR: backup archive verification failed at {bad}")
            return 4
        if "tcs_pos.db" not in z.namelist() or "backup_manifest.json" not in z.namelist():
            out.unlink(missing_ok=True)
            print("ERROR: required backup contents are missing.")
            return 5
    print("")
    print("BACKUP COMPLETED AND VERIFIED")
    print(f"File: {out}")
    print(f"Size: {out.stat().st_size:,} bytes")
    print("Database integrity: OK")
    print("Your original database was not modified.")
    print("")
    print("IMPORTANT: Keep a copy on another drive or USB as well.")
    return 0

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"BACKUP FAILED: {exc}")
        print("The original database was not intentionally changed.")
        raise SystemExit(1)
