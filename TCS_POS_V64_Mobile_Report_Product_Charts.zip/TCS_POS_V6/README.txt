THE CREAM STUDIO POS V48 — ZOMATO STOCK-ONLY DELIVERY

V48 NEW FEATURE
- Billing Dashboard has a separate “Delivered on Zomato (Stock Only)” action. Add the delivered products to the cart and click it to save a Zomato delivery record.
- This action accepts only active products that are eligible for the Inventory section and have an inventory batch. It validates stock on the server and deducts the delivered quantities from inventory using the existing oldest-batch-first consumption logic.
- No sales amount, price, payment, cash or online amount is recorded for Zomato delivery lines. Recent Bills and Past Sales show “Delivered on Zomato”, item names and quantities, and suppress the per-entry amount fields.
- Manual / Quick Add items cannot be included in this stock-only action. Use only saved inventory products. Normal cash/online/credit/split billing is unchanged.
- Removing a Zomato delivery record restores the associated inventory quantities using the existing bill-removal workflow. The Zomato entry is not editable as a cash sale.
- The package does not include tcs_pos.db. It adds no required database migration; existing products, bills, inventory, and prices are preserved.

SAFE UPDATE
1. Close the POS and make a backup copy of your existing tcs_pos.db.
2. Extract this ZIP separately.
3. Copy only index.html and server.py into your active TCS_POS_V6 folder, replacing those two application files.
4. Never replace or delete tcs_pos.db.
5. Start with START_POS.bat.
6. Test with a low quantity first and verify the inventory quantity in the Inventory page.

THE CREAM STUDIO POS V43 — FASTER STARTUP

- SQLite WAL mode is initialized once per server process instead of being reset on every database connection.
- Default catalogue seeding and legacy category cleanup run once per database; existing products and manually edited prices are not overwritten or deleted.
- No database is bundled in this ZIP. The app continues using your existing local tcs_pos.db.

SAFE UPDATE
1. Close the POS and make a backup copy of tcs_pos.db.
2. Extract this ZIP separately.
3. Copy only server.py and START_POS.bat into your existing POS folder.
4. Never replace or delete tcs_pos.db. Keep the rest of your current files.
5. Start with START_POS.bat.

THE CREAM STUDIO POS V30 — RESPONSIVE LAYOUT UPDATE

V30 CHANGES
- End of Sales PNG image now grows dynamically according to the complete number of bill rows, item-wise sales rows, and remaining-inventory rows. The image report no longer intentionally truncates the report to the first 120 bills/items or 140 inventory products.
- Added a collapse/expand arrow to the navigation sidebar. Expanded mode shows icon + label; collapsed mode shows only the navigation icons. The selection is remembered in this browser.
- Kept the full category/product browsing area prominent, increased the product grid to four columns on wider screens, and made the cart panel slightly narrower to reduce congestion. Smaller screens use responsive layouts.
- Existing prices, bills, inventory, payment records and database schema are unchanged by this layout-only update.

INSTALL / UPDATE V30 SAFELY
1. Close The Cream Studio POS.
2. Back up your existing tcs_pos.db file.
3. Extract this ZIP to a separate folder.
4. Copy the new index.html into your existing TCS_POS_V6 folder, replacing only the old index.html. Keep logo.png, server.py, catalog_source.py and other existing application files in place.
5. Do not delete, replace, or overwrite tcs_pos.db.
6. Run START_POS.bat again. If the browser shows the old layout, refresh the page with Ctrl+F5.

--- Previous version notes follow for reference ---

THE CREAM STUDIO POS V25 — MENU-CATEGORY INVENTORY CONTROL

V24 visual update: original logo and brand name are aligned together at the top-left. The default palette is a softer charcoal, brushed gold and warm ivory; other themes remain available in the theme selector. Keep logo.png beside server.py and index.html.

- V21 applies your three uploaded menu boards as the definitive Our Item list: Bento / 250 gm / 500 gm cakes, pastries, desserts, cheesecakes, hot items, single and sandwich waffles, all listed brownie variants, and menu-listed add-ons (vanilla/chocolate ice cream, extra chocolate, extra toppings, with ice cream). Only products in these menus are classified Our Item. Every other already-existing product—including dry cakes, cookies, rusk, cream rolls, birthday accessories and other unlisted products—is classified Other Item.
- New products require a ledger classification when created through Quick Add Product or Manage Product. The selection is saved with the product and becomes its default when added to future bills.
- Product-list import preview requires a per-row Our Item / Other Item classification for both new and existing products. The user's explicit choice applies to the catalogue row; historical bill lines remain unchanged by later menu imports.
- V21 performs a one-time, additive classification migration on your existing product catalogue and historical bill lines according to the three-menu rule. Prices, bill totals, customer records, imported Excel files, and product rows are retained; `tcs_pos.db` is never replaced. Existing saved End of Sales snapshots are rebuilt with the corrected Our/Other split while keeping their original generated timestamps. After migration, classification chosen for future products is not overwritten each time the app starts.

THE CREAM STUDIO POS V22 — MENU REVIEW + INVENTORY + DATE-WISE TRANSACTIONS

V22 NEW FEATURES
- Menu Upload & Review is available as its own sidebar section. Accepted formats: PDF, PNG/JPG/JPEG/WEBP/BMP/TIF/TIFF images, TXT/TEXT/Markdown/LOG, and CSV. Text PDFs are parsed locally. Image/scanned-PDF OCR requires Tesseract OCR for Windows in addition to the Python dependencies. The extracted names/categories/prices appear in a review table; every product needs an explicit Our Item / Other Item choice before apply. Exact duplicates in the same category are detected and collapsed to one review row, with source lines and conflicting prices shown for review. Same-name items across different categories are flagged for confirmation and kept separate unless the user edits them. OCR output can be imperfect, so inspect the preview before saving.
- Inventory is a separate sidebar page and shows only active Our Item products. Enter each batch with its manufacturing date and quantity. Batches 3 or more calendar days old with remaining stock appear in the inventory warning panel and a popup. The alert is a freshness-review reminder, not an automatic expiry determination. Stock is consumed oldest-manufacturing-date-first when bills are checked out. Once the first inventory batch is recorded for an Our Item product, stock tracking activates; at zero stock, the product is disabled on the billing dashboard and checkout is server-blocked until a new batch is added. Products without any inventory history remain sellable during rollout, to avoid unexpectedly blocking the entire existing catalogue.
- Inventory rows follow active catalogue products classified as Our Item. Menu uploads can add products, update matched products, and set classifications after per-item confirmation. Existing unrelated catalogue products are not deleted.
- Recent Bills are grouped into individual bordered date sections with a day heading, transaction count, Our/Other summaries, separate Cash and Online totals, and a day total so different dates do not visually mix.
- Inventory consumption is linked to saved bill items. Removing a bill restores the consumed quantities to their original batches; editing a bill restores its old consumption and validates/consumes the edited quantities again. Inventory ledger changes are stored locally in the POS database.

INSTALL / UPDATE SAFELY
1. Close The Cream Studio POS.
2. Make a backup copy of your existing tcs_pos.db file first.
3. Extract this ZIP to a separate folder.
4. Copy/replace the application files from the extracted TCS_POS_V6 folder into your existing TCS_POS_V6 folder: index.html, server.py, catalog_source.py, requirements.txt, INSTALL_REQUIREMENTS.bat, START_POS.bat, and README.txt. Do not overwrite or copy any database file from the ZIP.
5. KEEP your existing tcs_pos.db. Do not delete it or replace it with a blank database.
6. Run INSTALL_REQUIREMENTS.bat once after this update so the PDF/image import libraries are installed; an internet connection may be needed. For image/scanned-PDF OCR, install Tesseract OCR for Windows separately.
7. Run START_POS.bat and keep its command window open while using the POS.
8. The server makes safe, additive database changes: it adds source-file and worksheet metadata for Excel imports, daily closing records, item-to-product links, and inventory batch/consumption tables. It does not replace the database or delete existing bills, products, or imports.

V18–V21 FEATURES RETAINED + V22 MENU / INVENTORY UPDATES
- Removed the duplicate Recent Bills button from the top utility row. Recent Bills is accessible from the left sidebar only.
- Added Imported Excel Sheets to the sidebar. Open each imported workbook, choose a worksheet, and browse the data as a spreadsheet-like grid with worksheet names, column letters, original row numbers, blank rows within the stored range, and paging for large sheets.
- New Excel/CSV imports retain the exact original uploaded file in the local database. “Open Original” downloads the file as uploaded so its workbook formatting can be viewed in Excel. Previous imports made before this feature may not have their original file binary stored; they can be reconstructed from the saved cell values, but that reconstruction does not restore the original formatting or formulas.
- Added a Sales & Ledgers group in the sidebar, including Past Sales by Date, Our Item Ledger, Other Item Ledger, and End of Sales.
- End of Sales shows a date-specific closing with bill details, Our Item and Other Item sales/quantities, cash and online totals, cash/online allocations per item type, and packing/extra charges. Click Generate / Save End of Sales Ledger to store a dated snapshot. If a snapshot already exists, the POS asks before replacing it. Export Closing Excel produces a workbook with End of Sales Summary, Bill Summary, Our Item Ledger, Other Item Ledger, and Cash Online Ledger sheets.
- Added keyboard support using the existing billing/removal actions: pressing Enter while in the Customer Name field, on the checkout button, on a cart row, or with the page body focused generates the current bill (when the cart has items). Selecting a cart item then pressing Delete removes that selected cart item. Enter on a product button keeps its standard action of adding the product.
- Added an X control to close empty/inactive pending bill tabs. Tabs with items, a customer name, or packing selected are not closeable until emptied. At least one bill tab stays open.
- Existing products, item classifications, customer drafts, bill edit/remove/print, pricing editor, product-list import, current billing totals, and Our/Other ledgers remain.
- Added Quick Add Product to the billing menu. At busy times, enter a missing item name, price, quantity, Our Item/Other Item ledger classification, and either an existing category or a new category name. The new category appears automatically through the saved product. The item is immediately added to the current bill and saved in the product catalogue for future billing.
- If the same product already exists in the same category (case-insensitive match), it is reactivated if needed and the saved catalogue price is used; no duplicate is created and the existing price is not silently overwritten. If the current bill already contains that product with the opposite Our/Other classification, Quick Add keeps the extra quantity as a separate bill line so the ledger classification remains correct.

IMPORTANT NOTES
- Imported historical workbook rows are archived separately; they do not automatically become POS bills or affect sales totals.
- Past Sales and the ledgers read bills saved in tcs_pos.db.
- Cash/online item allocations are calculated proportionally against bill totals, while packing/extra charges are shown separately. Small rounding differences may occur at line level.
- Excel export requires openpyxl. If Excel export reports the library missing, run INSTALL_REQUIREMENTS.bat once and restart the POS.
- The POS remains a local Python app. Keep the server window open while using it. Do not expose port 8765 to the public internet or share the session token.

IMPORTANT: Keep logo.png in the same TCS_POS_V6 folder as server.py; do not move it into a subfolder.


THE CREAM STUDIO POS V25 — INVENTORY CATEGORY SCOPE
- Inventory now includes ONLY active Our Item products in these seven categories from the uploaded cake/pastry menu: Bento Cake, 250 GM Cake, 500 GM Cake, Pastry, Desserts, Cheesecake, and Hot Items.
- Any future product added in one of these categories is automatically included in Inventory if classified as Our Item. If classified as Other Item, it is not included.
- Products in all other categories (including waffle, brownie, add-ons, dry cakes, cookies, rusk, cream rolls, and birthday items) are excluded from Inventory regardless of their Our/Other label. Their prices and catalogue records are not modified by this update.
- The category filter applies to inventory listing, age alerts, stock blocking and stock consumption. Existing local tcs_pos.db is not included or replaced. Local product prices remain as currently saved.
- For the new scope, inventory batches belonging to categories outside the seven listed categories are ignored by the Inventory screen and stock control. They are not deleted from the database.

V25 SAFE UPDATE
1. Close POS and back up tcs_pos.db.
2. Extract this ZIP to a separate folder.
3. Copy index.html, server.py, and logo.png into the existing TCS_POS_V6 folder (catalog_source.py and database do not need to be replaced for this change).
4. Do not replace/delete tcs_pos.db.
5. Run START_POS.bat.

V26 UPDATE — INVENTORY QUANTITY REMOVAL & CUSTOMER CREDIT
- Inventory batch details now include Remove Qty. You can reduce only the unsold remaining quantity in that batch; stock already consumed by saved bills cannot be removed through this control.
- Billing has individual Cash, Online and Credit payment buttons.
- Credit requires a customer name and records the full bill amount as credit, without adding it to cash or online received totals.
- Customer Credit Ledger navigation lists credit bill date/time, customer, products, and amount.
- The database migration adds a credit column without deleting existing bills, products, prices or inventory.


THE CREAM STUDIO POS V29 — NAVIGATION, LEDGER & END-OF-SALES IMAGE
- Billing Dashboard header now keeps only End of Sales Report, Upload Menu / Product List, and Platform Integration actions. Excel import/export and catalogue management were removed from the Billing Dashboard header.
- Import Excel Sheet, Export Excel Sheet, and Imported Excel Sheets are available from the navigation under Data & Tools.
- Menu Upload / Product List is available only from the Billing Dashboard header.
- Product & Category Management is a single navigation section. It groups Add/Edit/Remove Product, Edit Product Prices, and Rename/Remove Category actions on one clean page.
- The navigation has one Ledger & Sales Accounts item. All Items, Our Item, Other Item and Past Sales by Date are filters inside the Ledger page; Our Item and Other Item are no longer separate navigation entries.
- End of Sales Report is in the Billing Dashboard header. It generates a downloadable PNG image showing daily bills, total sales, Our/Other split, Cash/Online/Credit sales, item-wise sales, and remaining inventory quantities by product. The inventory shown is the current stock when the image is generated, not a historical inventory snapshot.
- The existing optional Save / Update Closing Ledger and Export Closing Excel actions remain on the End of Sales page.
- These interface changes do not require a database migration and do not change existing product prices or historic bills.

V29 SAFE UPDATE
1. Close the POS and make a backup copy of your existing tcs_pos.db file.
2. Extract this ZIP into a new folder to test the update first.
3. To update the existing POS folder, replace index.html and README.txt with the copies from this ZIP. Other application files are unchanged in V29; keep your existing server.py, catalog_source.py, logo.png and requirements.txt.
4. Never delete or replace tcs_pos.db. If running the extracted folder instead, copy your existing tcs_pos.db into the extracted TCS_POS_V6 folder after making the backup.
5. Start the POS and check: (a) Excel actions are in navigation, (b) Upload Menu is only in the Billing Dashboard header, (c) Ledger has its internal filters, (d) End of Sales creates and downloads a PNG, and (e) remaining stock quantities look correct.
6. The code passed a JavaScript syntax check and Python compilation check. The complete live billing/database workflow has not been end-to-end tested in this environment, so validate with your backup and a test date before relying on the generated report.


THE CREAM STUDIO POS V37 — 58MM RECEIPT + WINDOWS PORTABILITY

58MM THERMAL PRINTER (MODEL M58BT-D)
- Receipt print CSS is sized for a 58mm paper roll and a conservative 48mm content width to reduce clipping on common 58mm thermal printers.
- In the Windows printer driver, select the 58mm roll/paper profile if available. In the browser print dialog, choose the M58BT-D printer, set scale to 100% / Actual size, margins to None (or minimum), and disable browser headers/footers. Driver paper settings override CSS in some Windows/browser combinations.
- Pair the printer in Windows Bluetooth settings or connect USB and install its correct Windows driver before printing. This app cannot install or select a printer driver automatically. First print a test receipt and adjust the paper profile if the specific driver uses a different printable width.

WINDOWS PORTABILITY
- START_POS.bat now creates a local .venv folder and installs requirements into it on first run. It prefers the Windows Python Launcher (py -3), then falls back to python. This isolates the app from global Python packages and many Windows/Python updates.
- A working Python 3 installation is still required; this folder is not a standalone EXE. If Python is missing on another Windows PC, install Python 3.11 or 3.12 from https://www.python.org/downloads/windows/ and enable the PATH/launcher options. First-time dependency installation needs internet.
- Keep the whole TCS_POS_V6 folder together. The database is stored beside server.py as tcs_pos.db. Back up this file before updating or moving the app. Never replace it with a blank database.
- Moving to another PC: close the POS, copy the entire folder including tcs_pos.db, install Python on the new PC if needed, then run START_POS.bat. Keep a separate backup before testing.
- Printer driver and paper-size settings are Windows-PC-specific and may need to be set again on a replacement Windows installation.

V40 UPDATE — CUSTOM RECEIPT MESSAGE
-----------------------------------
A new "Receipt Message" option is available in the left navigation panel.
Open it to type a custom message (up to 160 characters) that appears at the
bottom of each new or reprinted receipt. Use Save Message to keep it, or
Reset Default to restore "Thankyou for purchase." The brand name at the top
of the receipt remains THE CREAM STUDIO®.

The message is saved in this browser profile on this Windows computer. If you
move the POS to a different Windows/browser profile, configure the message there too.



TCS POS FULL BACKUP — IMPORTANT

WHAT THIS BACKUP INCLUDES
- A consistent SQLite snapshot of tcs_pos.db (including committed WAL data)
- Backend and app files: server.py, catalog_source.py, index.html, logo, requirements and launcher files
- Optional app-owned uploads/exports/attachments/data folders if they exist
- A manifest with file sizes, SHA-256 hashes and a database integrity-check result

HOW TO CREATE A BACKUP
1. Put backup_pos.py and BACKUP_POS.bat in the SAME active TCS_POS_V6 folder as server.py and tcs_pos.db.
2. Double-click BACKUP_POS.bat.
3. A verified ZIP will be created in the backups folder.
4. Copy that ZIP to a USB drive or another drive as a second copy.

IMPORTANT
- The downloaded package does NOT contain your live tcs_pos.db because that file is on your own Windows PC and was not included in the software ZIP you uploaded here. Run the backup tool in your actual working folder to capture your real data.
- Do not delete or replace tcs_pos.db when updating the software.
- Keep at least one backup outside the POS folder. If the PC/drive fails, a backup stored only on that same drive may be lost too.
- Before restoring, close the POS completely. Do not restore over an active database. Keep the original folder untouched and restore into a separate copy first.
- Browser-only preferences (for example theme/sidebar state and a custom receipt message stored in browser localStorage) are not in the backend database backup. They remain in that Windows browser profile unless exported separately.
- This tool does not upload anything to the internet.


IN-SOFTWARE BACKUP
Open Navigation > Data & Tools > Backup Data. Click Create Backup & Choose Save Location. In supported Chrome versions, choose a folder/file location in the save dialog. If the picker is unavailable, the ZIP downloads to the browser download location. For the fallback, enable Chrome Settings > Downloads > Ask where to save each file to get a save-location prompt.
The backup is generated locally and is not uploaded. Keep a second copy on a different drive. Keep the ZIP private because it contains business records. Browser localStorage preferences (including custom receipt message and unsaved draft bills) are not in the backend ZIP.


V43 + Discount option: Billing Dashboard supports a rupee discount amount deducted after packing charges. Existing database is preserved; startup adds the discount_amount column if missing. Back up tcs_pos.db before updating.


V52 ADDITION — OTHER ITEM INVENTORY
Open “Other Item Inventory” in the left navigation. Puff Pastry, Dry Cakes, Toast and Cookies are available as folders. Add subcategories/products and fill stock there. Stock is deducted on sale for products in these folders. See V52_UPDATE_NOTES.txt.

V53 UPDATE — PRODUCT PERFORMANCE
Open the new “Product Performance” item in the left navigation to view all-time item performance from saved sales. Our Item is on the left and Other Item is on the right, separated by a divider. Each side is sorted by quantity recorded, highest first and lowest last. The table includes category, quantity sold, recorded product sales value, bill count, and last-sold date. Active products with no recorded sales appear at the bottom with zero quantity. Zomato stock-only deliveries count toward quantity but not sales value because no amount is recorded. This view is read-only.
