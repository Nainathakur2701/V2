@echo off
setlocal
cd /d "%~dp0"
title The Cream Studio POS - Full Data Backup
echo ===============================================
echo   THE CREAM STUDIO POS - FULL DATA BACKUP
echo ===============================================
echo.
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" backup_pos.py
  set "RESULT=%ERRORLEVEL%"
  goto DONE
)
where py >nul 2>nul
if not errorlevel 1 (
  py -3 backup_pos.py
  set "RESULT=%ERRORLEVEL%"
  goto DONE
)
where python >nul 2>nul
if not errorlevel 1 (
  python backup_pos.py
  set "RESULT=%ERRORLEVEL%"
  goto DONE
)
echo Python was not found. Open the folder on the PC where TCS POS is installed.
set "RESULT=1"
:DONE
echo.
if "%RESULT%"=="0" (
  echo Backup created inside the backups folder.
) else (
  echo Backup did not complete. Read the error above.
)
pause
exit /b %RESULT%
