import tkinter as tk
from tkinter import ttk,messagebox,filedialog
import sqlite3,os,csv,datetime,subprocess,tempfile
BASE=os.path.dirname(os.path.abspath(__file__)); DB=os.path.join(BASE,'tcs_pos.db')
con=sqlite3.connect(DB);con.execute('CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY,category TEXT,name TEXT,price REAL,active INTEGER DEFAULT 1,UNIQUE(category,name))');con.execute('CREATE TABLE IF NOT EXISTS bills(id INTEGER PRIMARY KEY AUTOINCREMENT,created TEXT,payment TEXT,total REAL,cash REAL,online REAL)');con.execute('CREATE TABLE IF NOT EXISTS bill_items(bill_id INTEGER,product TEXT,qty INTEGER,price REAL)');con.commit()
CATALOG={
'Bento Cake': [('Butterscotch',230),('Black Forest',230),('Chocolate Truffle',250),('Coffee',250)],
'250 GM Cake': [(x,300) for x in ['Pineapple','Blueberry','Butterscotch','Black Forest','Vanilla','Strawberry','White Forest']]+[(x,350) for x in ['Chocolate Truffle','Lotus Biscoff','Caramel','Black Current']]+[('Choco Walnut',450)]+[(x,400) for x in ['Kitkat','Nutella','Choco Vanilla','Honey Almond','Cookie N Cream','Dairy Milk']],
'500 GM Cake':[(x,450) for x in ['Pineapple','Blueberry','Butterscotch','Black Forest']]+[('Chocolate Truffle',650)],
'Pastry':[('Pineapple',70),('Butterscotch',80),('Blueberry',80),('Black Forest',80),('Chocolate',100),('Truffle',140),('Biscoff',140),('Mix Fruit',140)],
'Desserts':[('Handmade Lollipop',10),('Chocolate Swiss Roll',80),('Death by Chocolate',100),('Truffle Loaf',140)],
'Cheesecake':[(x,230) for x in ['Blueberry','Nutella','Biscoff']],
'Hot Items':[('Brownie Bites',140),('Chocolawa',80),('Triple Chocolate Cream Roll',50)],
'Single Waffle':[('Single Chocolate (Dark/White/Milk)',80),('Two Chocolate Mix',90),('Three Chocolate Mix',100)],
'Sandwich Waffle':[('Dark/Milk/White Chocolate',170),('Choco Pie Chocolate',180),('Gems Chocolate',180),('Crunchy Kitkat',190),('Cookie & Cream',190),('Crunchy Nutella Kitkat',200),('Nutella',220),('Triple Chocolate',240),('Brownie Chocolate',260),('Truffle Chocolate',260),('Lotus Biscoff Waffle',280)],
'Waffle Add-on':[('Vanilla Ice Cream',25),('Chocolate Ice Cream',50),('Extra Chocolate',30),('Packaging Charge',10)],
'Classic Chocolate Brownie':[('Rich White Chocolate',100),('Milk Chocolate Creme',100),('Dark Chocolate Ganache',100),('Classic Triple Chocolate',120)],
'Chocolate Favourites Brownie':[('Dairy Milk Choco Brownie',140),('Perk Choco Brownie',150),('KitKat Crunch Brownie',160),('Munchy Crunchy Brownie',170),('Choco Gems Brownie',180)],
'Signature Spread Brownie':[('Choco Pie Delight Brownie',180),('Oreo Crunch Brownie',200),('Nutella Classic Brownie',220),('Biscoff Bliss Brownie',220)],
'Silk Delights Brownie':[('Silk Chocolate Brownie',180),('Silk Oreo Brownie',200),('Silk Fruit & Nut Brownie',220),('Silk Roast Almond Brownie',220),('Silk Hazelnut Brownie',230),('Silk Caramello Brownie',230),('Silk Ganache Brownie',250),('Silk Mousse Brownie',260)],
'Brownie Add-on':[('Extra Chocolate',30),('Extra Toppings',30),('With Ice Cream',60)]}
for category,items in CATALOG.items():
 for name,price in items:con.execute('INSERT OR IGNORE INTO products(category,name,price) VALUES(?,?,?)',(category,name,price))
con.commit()
BG='#F7F2E9';DARK='#392116';GOLD='#B98B3B';WHITE='#FFFFFF';root=tk.Tk();root.title('THE CREAM STUDIO® | POS V2');root.geometry('1330x810');root.minsize(1050,680);root.configure(bg=BG)
style=ttk.Style();style.theme_use('clam');style.configure('Treeview',font=('Segoe UI',10),rowheight=31,background=WHITE,fieldbackground=WHITE);style.configure('Treeview.Heading',font=('Segoe UI',10,'bold'),background='#E8DCC7',foreground=DARK)
header=tk.Frame(root,bg=DARK,height=92);header.pack(fill='x');tk.Label(header,text='✦  THE CREAM STUDIO®',font=('Georgia',23,'bold'),bg=DARK,fg='#F5DCA2').pack(side='left',padx=28,pady=15);tk.Label(header,text='EGGLESS CAKING & BAKING ACADEMY   •   OFFLINE POS',font=('Segoe UI',10,'bold'),bg=DARK,fg='#F8EEE0').pack(side='right',padx=24)
main=tk.Frame(root,bg=BG);main.pack(fill='both',expand=True,padx=16,pady=14)
left=tk.Frame(main,bg=BG);left.pack(side='left',fill='both',expand=True);right=tk.Frame(main,bg=WHITE,width=390,highlightbackground='#D8C6A8',highlightthickness=1);right.pack(side='right',fill='y',padx=(14,0));right.pack_propagate(False)
search=tk.StringVar();category=tk.StringVar(value='All Products');cart={}
tk.Label(left,text='Explore Menu',font=('Georgia',19,'bold'),fg=DARK,bg=BG).pack(anchor='w');bar=tk.Frame(left,bg=BG);bar.pack(fill='x',pady=9);tk.Label(bar,text='Search:',bg=BG,fg=DARK).pack(side='left');tk.Entry(bar,textvariable=search,font=('Segoe UI',12),relief='solid',bd=1).pack(side='left',fill='x',expand=True,padx=8)
catbox=ttk.Combobox(left,textvariable=category,state='readonly',values=['All Products']+list(CATALOG),width=26,font=('Segoe UI',10));catbox.pack(fill='x',pady=(0,9))
product_area=tk.Frame(left,bg=BG);product_area.pack(fill='both',expand=True);canvas=tk.Canvas(product_area,bg=BG,highlightthickness=0);scroll=ttk.Scrollbar(product_area,orient='vertical',command=canvas.yview);product_grid=tk.Frame(canvas,bg=BG);window=canvas.create_window((0,0),window=product_grid,anchor='nw');canvas.configure(yscrollcommand=scroll.set);canvas.pack(side='left',fill='both',expand=True);scroll.pack(side='right',fill='y');product_grid.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')));canvas.bind('<Configure>',lambda e:canvas.itemconfigure(window,width=e.width))
tk.Label(right,text='CURRENT BILL',font=('Georgia',18,'bold'),bg=WHITE,fg=DARK).pack(anchor='w',padx=17,pady=(19,5));tk.Label(right,text='Tap a product to add it to the cart',bg=WHITE,fg='#857666').pack(anchor='w',padx=17)
cart_table=ttk.Treeview(right,columns=('item','qty','amount'),show='headings',height=12);cart_table.pack(fill='both',expand=True,padx=12,pady=12);[(cart_table.heading(k,text=t),cart_table.column(k,width=w,anchor='w' if k=='item' else 'center')) for k,t,w in [('item','Item',210),('qty','Qty',45),('amount','₹',85)]]
cart_buttons=tk.Frame(right,bg=WHITE);cart_buttons.pack(fill='x',padx=12)
subtotal=tk.StringVar(value='₹0.00');tk.Label(right,textvariable=subtotal,font=('Georgia',22,'bold'),bg=WHITE,fg=DARK).pack(anchor='e',padx=18,pady=12)
pay=tk.StringVar(value='Cash');payrow=tk.Frame(right,bg=WHITE);payrow.pack(fill='x',padx=15);tk.Label(payrow,text='Payment',bg=WHITE).pack(side='left');ttk.Combobox(payrow,textvariable=pay,values=['Cash','Online','Split'],state='readonly',width=12).pack(side='right')
split=tk.StringVar(value='0');sr=tk.Frame(right,bg=WHITE);sr.pack(fill='x',padx=15,pady=8);tk.Label(sr,text='Cash amount (for Split)',bg=WHITE).pack(side='left');tk.Entry(sr,textvariable=split,width=10).pack(side='right')
printer=tk.StringVar();pr=tk.Frame(right,bg=WHITE);pr.pack(fill='x',padx=15,pady=5);tk.Label(pr,text='Windows Printer',bg=WHITE).pack(side='left');printer_combo=ttk.Combobox(pr,textvariable=printer,width=22);printer_combo.pack(side='right')
def printers():
 try:
  import win32print
  return [p[2] for p in win32print.EnumPrinters(2)]
 except Exception:return []
printer_combo['values']=printers()
def total():return sum(v[1]*v[2] for v in cart.values())
def redraw_cart():
 for x in cart_table.get_children():cart_table.delete(x)
 for k,(name,price,q) in cart.items():cart_table.insert('','end',iid=str(k),values=(name,q,f'{price*q:.2f}'))
 subtotal.set(f'₹{total():,.2f}')
def add(pid,name,price):
 if pid in cart:cart[pid]=(name,price,cart[pid][2]+1)
 else:cart[pid]=(name,price,1)
 redraw_cart()
def adjust(delta):
 sel=cart_table.selection()
 if not sel:return
 k=int(sel[0]);name,price,q=cart[k];q+=delta
 if q<=0:del cart[k]
 else:cart[k]=(name,price,q)
 redraw_cart()
def button(parent,text,cmd,bg=DARK,fg='white'):
 return tk.Button(parent,text=text,command=cmd,bg=bg,fg=fg,activebackground=GOLD,activeforeground='white',relief='flat',font=('Segoe UI',10,'bold'),cursor='hand2',padx=12,pady=9)
button(cart_buttons,'− Qty',lambda:adjust(-1)).pack(side='left',expand=True,fill='x',padx=2);button(cart_buttons,'+ Qty',lambda:adjust(1)).pack(side='left',expand=True,fill='x',padx=2);button(cart_buttons,'Clear',lambda:(cart.clear(),redraw_cart()),'#92675B').pack(side='left',expand=True,fill='x',padx=2)
def draw_products(*args):
 for w in product_grid.winfo_children():w.destroy()
 q=search.get().lower().strip();c=category.get();rows=con.execute('SELECT id,category,name,price FROM products WHERE active=1 ORDER BY category,name').fetchall();rows=[r for r in rows if (c=='All Products' or r[1]==c) and (q in r[2].lower() or q in r[1].lower())]
 for i,(pid,cat,name,price) in enumerate(rows):
  f=tk.Frame(product_grid,bg=WHITE,highlightbackground='#E6D9C8',highlightthickness=1,padx=12,pady=12);f.grid(row=i//3,column=i%3,sticky='nsew',padx=5,pady=5);tk.Label(f,text=cat.upper(),font=('Segoe UI',8,'bold'),fg='#A07537',bg=WHITE).pack(anchor='w');tk.Label(f,text=name,font=('Segoe UI',11,'bold'),fg=DARK,bg=WHITE,wraplength=185,justify='left').pack(anchor='w',fill='x',pady=5);tk.Label(f,text=f'₹{price:g}',font=('Segoe UI',14,'bold'),fg=DARK,bg=WHITE).pack(anchor='w');button(f,'+ Add to bill',lambda a=pid,b=name,p=price:add(a,b,p),GOLD).pack(fill='x',pady=(8,0))
 for j in range(3):product_grid.grid_columnconfigure(j,weight=1)
 canvas.yview_moveto(0)
search.trace_add('write',draw_products);category.trace_add('write',draw_products)
def receipt(bid,created,payment,t,cash,online,items):
 lines=['THE CREAM STUDIO','100% EGGLESS','-'*32,f'Bill #{bid}  {created[:16]}','-'*32]
 for name,price,qty in items:lines.extend([name[:32],f' {qty} x Rs.{price:.2f} = Rs.{price*qty:.2f}'])
 lines+=['-'*32,f'TOTAL: Rs.{t:.2f}',f'Cash: Rs.{cash:.2f}',f'Online: Rs.{online:.2f}',f'Payment: {payment}','Thank you! Visit again.','\n\n\n'];return '\n'.join(lines)
def print_receipt(content):
 name=printer.get().strip()
 if not name:messagebox.showinfo('Printer','Select an installed Windows printer. Bill is saved.');return
 try:
  import win32print
  h=win32print.OpenPrinter(name)
  try:
   job=win32print.StartDocPrinter(h,1,('TCS Receipt',None,'RAW'));win32print.StartPagePrinter(h);win32print.WritePrinter(h,content.encode('cp437','replace'));win32print.EndPagePrinter(h);win32print.EndDocPrinter(h)
  finally:win32print.ClosePrinter(h)
 except Exception as e:messagebox.showwarning('Print issue','Bill saved, but printer could not print. Check Windows printer driver / RAW support.\n'+str(e))
def checkout():
 if not cart:return messagebox.showwarning('Empty bill','Add at least one product.')
 t=round(total(),2);method=pay.get()
 try:
  cash=t if method=='Cash' else (0 if method=='Online' else round(float(split.get()),2))
  if cash<0 or cash>t:raise ValueError('Cash must be between 0 and total')
 except ValueError:return messagebox.showerror('Payment','Enter valid cash amount for split payment')
 online=round(t-cash,2);now=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S');items=list(cart.values())
 with con:
  cur=con.execute('INSERT INTO bills(created,payment,total,cash,online) VALUES(?,?,?,?,?)',(now,method,t,cash,online));bid=cur.lastrowid
  con.executemany('INSERT INTO bill_items(bill_id,product,qty,price) VALUES(?,?,?,?)',[(bid,n,q,p) for n,p,q in items])
 txt=receipt(bid,now,method,t,cash,online,items);cart.clear();redraw_cart()
 if messagebox.askyesno('Bill saved',f'Bill #{bid} saved successfully.\nTotal ₹{t:.2f}\nPrint receipt?'):print_receipt(txt)
def export():
 path=filedialog.asksaveasfilename(defaultextension='.csv',filetypes=[('Excel CSV','*.csv')],initialfile='TCS_Bills.csv')
 if not path:return
 with open(path,'w',encoding='utf-8-sig',newline='') as f:
  w=csv.writer(f);w.writerow(['Bill ID','Date','Payment','Total','Cash','Online']);w.writerows(con.execute('SELECT id,created,payment,total,cash,online FROM bills ORDER BY id'))
 messagebox.showinfo('Export','Sales exported.')
def manage():
 win=tk.Toplevel(root);win.title('Manage product prices');win.geometry('650x500');lst=ttk.Treeview(win,columns=('id','category','name','price'),show='headings');lst.pack(fill='both',expand=True)
 for c in ('id','category','name','price'):lst.heading(c,text=c.title());lst.column(c,width=65 if c=='id' else 175)
 def reload():
  for x in lst.get_children():lst.delete(x)
  for r in con.execute('SELECT id,category,name,price FROM products ORDER BY category,name'):lst.insert('','end',values=r)
 def edit():
  s=lst.selection()
  if not s:return
  vals=lst.item(s[0],'values');popup=tk.Toplevel(win);popup.title('Edit product');fields=[]
  for title,v in zip(('Category','Name','Price'),vals[1:]):
   tk.Label(popup,text=title).pack();e=tk.Entry(popup,width=40);e.insert(0,str(v));e.pack(padx=20,pady=5);fields.append(e)
  def save():
   try:
    cat,name,price=[e.get().strip() for e in fields];p=float(price)
    if not cat or not name or p<0:raise ValueError()
    con.execute('UPDATE products SET category=?,name=?,price=? WHERE id=?',(cat,name,p,int(vals[0])));con.commit();popup.destroy();reload();draw_products()
   except Exception:messagebox.showerror('Invalid','Check category, name, price or duplicate product')
  button(popup,'Save',save).pack(pady=15)
 def new():
  con.execute('INSERT INTO products(category,name,price) VALUES(?,?,?)',('New Category','New Product '+str(datetime.datetime.now().timestamp()),0));con.commit();reload()
 button(win,'Edit selected',edit).pack(side='left',padx=10,pady=8);button(win,'Add new product',new).pack(side='left',padx=10,pady=8);reload()
button(right,'SAVE BILL & PRINT',checkout,GOLD).pack(fill='x',padx=15,pady=(10,5));button(right,'Export Sales CSV',export).pack(fill='x',padx=15,pady=4);button(right,'Manage Products & Prices',manage).pack(fill='x',padx=15,pady=(4,16));draw_products();root.mainloop()
