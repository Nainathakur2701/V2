import ast,sqlite3,json,os,datetime,csv,io,threading,webbrowser,secrets,ipaddress,socket,base64,hashlib,os.path,re,mimetypes,tempfile,zipfile
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from urllib.parse import urlparse,parse_qs
ROOT=os.path.dirname(os.path.abspath(__file__));DB=os.path.join(ROOT,'tcs_pos.db');TOKEN=secrets.token_urlsafe(24)
source=open(os.path.join(ROOT,'catalog_source.py'),encoding='utf-8').read();node=next(n for n in ast.parse(source).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CATALOG' for t in n.targets));catalog=eval(compile(ast.Expression(node.value),'catalog','eval'),{'__builtins__':{}},{})
_wal_ready=False
_wal_lock=threading.Lock()
def db():
 global _wal_ready
 c=sqlite3.connect(DB,timeout=15);c.row_factory=sqlite3.Row
 if not _wal_ready:
  with _wal_lock:
   if not _wal_ready:
    c.execute('PRAGMA journal_mode=WAL');_wal_ready=True
 c.execute('PRAGMA busy_timeout=15000');return c
with db() as c:
 c.execute('CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY,category TEXT NOT NULL,name TEXT NOT NULL,price REAL NOT NULL,active INTEGER DEFAULT 1,UNIQUE(category,name))')
 product_cols={r['name'] for r in c.execute('PRAGMA table_info(products)')}
 if 'item_type' not in product_cols:
  # All products already in the uploaded menu/catalogue start as Our Item.
  c.execute("ALTER TABLE products ADD COLUMN item_type TEXT NOT NULL DEFAULT 'Our Item'")
 c.execute("UPDATE products SET item_type='Other Item' WHERE item_type IS NULL OR trim(item_type)='' OR item_type NOT IN ('Our Item','Other Item')")
 c.execute('CREATE TABLE IF NOT EXISTS bills(id INTEGER PRIMARY KEY,created TEXT,payment TEXT,total REAL,cash REAL,online REAL)')
 cols_bill={r['name'] for r in c.execute('PRAGMA table_info(bills)')}
 if 'customer_name' not in cols_bill:c.execute("ALTER TABLE bills ADD COLUMN customer_name TEXT NOT NULL DEFAULT ''")
 if 'credit' not in cols_bill:c.execute("ALTER TABLE bills ADD COLUMN credit REAL NOT NULL DEFAULT 0")
 if 'discount_amount' not in cols_bill:c.execute('ALTER TABLE bills ADD COLUMN discount_amount REAL NOT NULL DEFAULT 0')
 c.execute('CREATE TABLE IF NOT EXISTS bill_items(bill_id INTEGER,product TEXT,qty INTEGER,price REAL)')
 c.execute("CREATE TABLE IF NOT EXISTS credit_payments(id INTEGER PRIMARY KEY AUTOINCREMENT,bill_id INTEGER NOT NULL,paid_at TEXT NOT NULL,amount REAL NOT NULL CHECK(amount>0),method TEXT NOT NULL CHECK(method IN ('Cash','Online')),note TEXT NOT NULL DEFAULT '')")
 c.execute('CREATE INDEX IF NOT EXISTS idx_credit_payments_bill ON credit_payments(bill_id)')
 # Safe additive migration: retain all old bill rows and add item classification.
 cols={r['name'] for r in c.execute('PRAGMA table_info(bill_items)')}
 if 'item_type' not in cols:
  c.execute("ALTER TABLE bill_items ADD COLUMN item_type TEXT NOT NULL DEFAULT 'Our Item'")
  # Older databases encoded classification as a prefix inside the product text.
  c.execute("UPDATE bill_items SET item_type=CASE WHEN product LIKE 'Other Item - %' THEN 'Other Item' WHEN product LIKE 'Our Item - %' THEN 'Our Item' ELSE 'Other Item' END")
 if 'product_id' not in cols:
  c.execute('ALTER TABLE bill_items ADD COLUMN product_id INTEGER')
 c.execute('CREATE INDEX IF NOT EXISTS idx_bill_items_bill_id ON bill_items(bill_id)')
 c.execute('CREATE TABLE IF NOT EXISTS inventory_batches(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER NOT NULL,manufacturing_date TEXT NOT NULL,qty_received INTEGER NOT NULL CHECK(qty_received>0),qty_remaining INTEGER NOT NULL CHECK(qty_remaining>=0),created_at TEXT NOT NULL)')
 c.execute('CREATE TABLE IF NOT EXISTS other_inventory_folders(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,parent_id INTEGER,active INTEGER NOT NULL DEFAULT 1,UNIQUE(parent_id,name))')
 for _folder in ('Puff Pastry','Dry Cakes','Toast','Cookies'):
  if not c.execute('SELECT 1 FROM other_inventory_folders WHERE parent_id IS NULL AND lower(name)=lower(?) AND active=1',(_folder,)).fetchone():
   c.execute('INSERT INTO other_inventory_folders(name,parent_id,active) VALUES(?,NULL,1)',(_folder,))
 c.execute('CREATE INDEX IF NOT EXISTS idx_inventory_product_date ON inventory_batches(product_id,manufacturing_date,id)')
 c.execute('CREATE TABLE IF NOT EXISTS inventory_consumptions(id INTEGER PRIMARY KEY AUTOINCREMENT,bill_id INTEGER NOT NULL,batch_id INTEGER NOT NULL,product_id INTEGER NOT NULL,qty INTEGER NOT NULL CHECK(qty>0))')
 c.execute('CREATE INDEX IF NOT EXISTS idx_inventory_consumptions_bill ON inventory_consumptions(bill_id)')
 c.execute('CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL)')
 c.execute('CREATE TABLE IF NOT EXISTS excel_imports(id INTEGER PRIMARY KEY,filename TEXT NOT NULL,imported_at TEXT NOT NULL,row_count INTEGER NOT NULL,file_hash TEXT UNIQUE NOT NULL)')
 cols_import={r['name'] for r in c.execute('PRAGMA table_info(excel_imports)')}
 if 'source_data' not in cols_import:c.execute('ALTER TABLE excel_imports ADD COLUMN source_data BLOB')
 if 'source_ext' not in cols_import:c.execute("ALTER TABLE excel_imports ADD COLUMN source_ext TEXT NOT NULL DEFAULT ''")
 c.execute('CREATE TABLE IF NOT EXISTS excel_import_rows(id INTEGER PRIMARY KEY,import_id INTEGER NOT NULL,sheet_name TEXT NOT NULL,row_number INTEGER NOT NULL,row_json TEXT NOT NULL,FOREIGN KEY(import_id) REFERENCES excel_imports(id) ON DELETE CASCADE)')
 c.execute('CREATE TABLE IF NOT EXISTS excel_import_sheets(id INTEGER PRIMARY KEY,import_id INTEGER NOT NULL,sheet_name TEXT NOT NULL,max_row INTEGER NOT NULL DEFAULT 0,max_column INTEGER NOT NULL DEFAULT 0,nonempty_rows INTEGER NOT NULL DEFAULT 0,UNIQUE(import_id,sheet_name),FOREIGN KEY(import_id) REFERENCES excel_imports(id) ON DELETE CASCADE)')
 c.execute('CREATE TABLE IF NOT EXISTS daily_closings(sales_date TEXT PRIMARY KEY,generated_at TEXT NOT NULL,snapshot_json TEXT NOT NULL)')
 c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('packing_charge','10')")
 catalog_seed=c.execute("SELECT value FROM settings WHERE key='catalog_seed_v43'").fetchone()
 if not catalog_seed:
  c.execute("UPDATE products SET category='Add-ons' WHERE category IN ('Waffle Add-on','Brownie Add-on') AND name!='Packaging Charge'")
  c.execute("UPDATE products SET active=0 WHERE name='Packaging Charge' AND category IN ('Waffle Add-on','Brownie Add-on')")
  # Keep every birthday accessory inside one single category. This also migrates existing databases.
  c.execute("UPDATE products SET category='Birthday Items' WHERE category IN ('Birthday Items - Popper','Birthday Items - Flower & Accessories')")
  for name,price in [('Vanilla Ice Cream',25),('Chocolate Ice Cream',50),('Extra Chocolate',30),('Extra Toppings',30),('With Ice Cream',60)]:
   c.execute('INSERT OR IGNORE INTO products(category,name,price) VALUES(?,?,?)',('Add-ons',name,price))
  for category,items in catalog.items():
   if category in ('Waffle Add-on','Brownie Add-on'):continue
   for name,price in items:c.execute('INSERT OR IGNORE INTO products(category,name,price) VALUES(?,?,?)',(category,name,price))
  # New items from the two supplied PDF price lists; never overwrite existing user edits.
  pdf_catalog={
   'Dry Cakes':[('Tutti Frutti Cake - Mini',90),('Mawa Malai Cake - Mini',90),('Chocolate Cake - Mini',100),('Tutti Frutti Cake - Big',220),('Mawa Malai Cake - Big',220),('Chocolate Cake - Big',230)],
   'Cookies':[('Choco Chip Cookies',140),('Atta Elaichi Cookies',140),('Atta Jeera Cookies',140)],
   'Rusk':[('Tilli Toast',150),('Atta Toast',90)],
   'Cream Rolls':[('Chocolate Cream Roll',20),('Vanilla Cream Roll',20)],
   'Birthday Items':[('Small Popper',20),('Medium Popper',30),('Big Popper',80),('Lilly',120),('Rose',120),('Crown',100),('Hairband',90),('Keychain',80)]}
  for category,items in pdf_catalog.items():
   for name,price in items:c.execute('INSERT OR IGNORE INTO products(category,name,price) VALUES(?,?,?)',(category,name,price))
  c.execute("INSERT INTO settings(key,value) VALUES('catalog_seed_v43','1')")
 # V21: Only items listed in the three uploaded menus are Our Item.
 # All other existing catalogue items are Other Item. This is a one-time migration
 # so a future, user-selected classification is not overwritten on every launch.
 menu_categories={
  'Bento Cake','250 GM Cake','500 GM Cake','Pastry','Desserts','Cheesecake','Hot Items',
  'Single Waffle','Sandwich Waffle','Classic Chocolate Brownie',
  'Chocolate Favourites Brownie','Signature Spread Brownie','Silk Delights Brownie'
 }
 def normalized_product_name(value):
  value=str(value or '').strip()
  for prefix in ('Our Item - ','Other Item - '):
   if value.startswith(prefix):
    value=value[len(prefix):]
    break
  return re.sub(r'[^a-z0-9]+','',value.casefold())
 menu_names=set()
 for menu_category in menu_categories:
  for menu_name,_menu_price in catalog.get(menu_category,[]):
   menu_names.add(normalized_product_name(menu_name))
 # Waffle and brownie add-ons printed on the uploaded menu boards also count as Our Item.
 for menu_category in ('Waffle Add-on','Brownie Add-on'):
  for menu_name,_menu_price in catalog.get(menu_category,[]):
   if normalized_product_name(menu_name)!='packagingcharge':
    menu_names.add(normalized_product_name(menu_name))
 applied=c.execute("SELECT value FROM settings WHERE key='menu_based_classification_v21'").fetchone()
 if not applied:
  for product_row in c.execute('SELECT id,name FROM products').fetchall():
   kind='Our Item' if normalized_product_name(product_row['name']) in menu_names else 'Other Item'
   c.execute('UPDATE products SET item_type=? WHERE id=?',(kind,product_row['id']))
  # Reclassify old bill rows one time so historical ledgers match the three-menu rule.
  for bill_item in c.execute('SELECT rowid,product FROM bill_items').fetchall():
   kind='Our Item' if normalized_product_name(bill_item['product']) in menu_names else 'Other Item'
   c.execute('UPDATE bill_items SET item_type=? WHERE rowid=?',(kind,bill_item['rowid']))
  c.execute("INSERT INTO settings(key,value) VALUES('menu_based_classification_v21','1')")
# V61: safely link Cream Roll products without violating UNIQUE(category,name).
# Some installations already have a product row at the destination category. In that case,
# keep the destination row as canonical, transfer stock batches to it, and deactivate the
# duplicate source row instead of attempting a conflicting category UPDATE.
with db() as c:
 root=c.execute("SELECT id FROM other_inventory_folders WHERE parent_id IS NULL AND lower(name)='puff pastry' AND active=1 ORDER BY id LIMIT 1").fetchone()
 if root:
  sub=c.execute("SELECT id FROM other_inventory_folders WHERE parent_id=? AND lower(name)='cream roll' AND active=1 LIMIT 1",(root['id'],)).fetchone()
  if not sub:c.execute("INSERT INTO other_inventory_folders(name,parent_id,active) VALUES('Cream Roll',?,1)",(root['id'],))
 for _cream_name in ('Chocolate Cream Roll','Vanilla Cream Roll'):
  _rows=c.execute("SELECT id,category FROM products WHERE lower(trim(name))=lower(?) ORDER BY CASE WHEN lower(category)='puff pastry / cream roll' THEN 0 ELSE 1 END,id",(_cream_name,)).fetchall()
  if not _rows: continue
  _target=next((r for r in _rows if str(r['category']).strip().casefold()=='puff pastry / cream roll'),None)
  if _target is None:
   _target=_rows[0]
   c.execute("UPDATE products SET category='Puff Pastry / Cream Roll',item_type='Other Item',active=1 WHERE id=?",(_target['id'],))
  else:
   c.execute("UPDATE products SET item_type='Other Item',active=1 WHERE id=?",(_target['id'],))
  for _duplicate in _rows:
   if int(_duplicate['id'])==int(_target['id']): continue
   # Preserve all batch quantities/history by moving stock lots before deactivating the duplicate.
   c.execute('UPDATE inventory_batches SET product_id=? WHERE product_id=?',(_target['id'],_duplicate['id']))
   c.execute('UPDATE products SET active=0 WHERE id=?',(_duplicate['id'],))
# Inventory is intentionally limited to the categories in the user's cake/pastry menu.
# New products added in these categories are automatically inventory-managed; products
# in all other categories are excluded even if their item_type is Our Item.
INVENTORY_MANAGED_CATEGORIES={
 'Bento Cake','250 GM Cake','500 GM Cake','Pastry','Desserts','Cheesecake','Hot Items'
}
OTHER_INVENTORY_ROOTS={'Puff Pastry','Dry Cakes','Toast','Cookies'}
# Load any user-renamed active root folders so their products remain inventory-managed after restart.
try:
 with db() as _c:
  OTHER_INVENTORY_ROOTS.update(r['name'] for r in _c.execute('SELECT name FROM other_inventory_folders WHERE parent_id IS NULL AND active=1'))
except Exception:pass
def category_key(value):
 return re.sub(r'\s+',' ',str(value or '').strip()).casefold()
def is_inventory_managed_category(value):
 return category_key(value) in {category_key(x) for x in INVENTORY_MANAGED_CATEGORIES}
def is_inventory_managed_product(row):
 if not row:return False
 kind=str(row['item_type'] or '')
 cat=str(row['category'] or '').strip()
 if kind=='Our Item':return is_inventory_managed_category(cat)
 if kind=='Other Item':
  root=re.split(r'\s*(?:/|›|>)\s*', cat, maxsplit=1)[0].strip()
  return category_key(root) in {category_key(x) for x in OTHER_INVENTORY_ROOTS}
 return False

def inventory_status(c,product_id):
 tracked=c.execute('SELECT 1 FROM inventory_batches WHERE product_id=? LIMIT 1',(product_id,)).fetchone() is not None
 stock=int(c.execute('SELECT COALESCE(SUM(qty_remaining),0) FROM inventory_batches WHERE product_id=?',(product_id,)).fetchone()[0] or 0)
 return tracked,stock

def restore_bill_inventory(c,bill_id):
 rows=c.execute('SELECT batch_id,qty FROM inventory_consumptions WHERE bill_id=?',(bill_id,)).fetchall()
 for row in rows:c.execute('UPDATE inventory_batches SET qty_remaining=qty_remaining+? WHERE id=?',(int(row['qty']),int(row['batch_id'])))
 c.execute('DELETE FROM inventory_consumptions WHERE bill_id=?',(bill_id,))
 return len(rows)

def consume_inventory(c,bill_id,product_id,qty):
 prod=c.execute('SELECT item_type,active,name,category FROM products WHERE id=?',(product_id,)).fetchone()
 if not prod or not prod['active'] or not is_inventory_managed_product(prod):return
 tracked,stock=inventory_status(c,product_id)
 if not tracked:raise ValueError(f"{prod['name']} has no inventory batch. Add stock in Inventory / Other Item Inventory before selling it.")
 if stock<int(qty):raise ValueError(f"Not enough inventory for {prod['name']}. Available: {stock}, requested: {qty}. Add a new inventory batch first.")
 remaining=int(qty)
 batches=c.execute('SELECT id,qty_remaining FROM inventory_batches WHERE product_id=? AND qty_remaining>0 ORDER BY manufacturing_date,id',(product_id,)).fetchall()
 for batch in batches:
  take=min(remaining,int(batch['qty_remaining']))
  if take<=0:continue
  c.execute('UPDATE inventory_batches SET qty_remaining=qty_remaining-? WHERE id=?',(take,batch['id']))
  c.execute('INSERT INTO inventory_consumptions(bill_id,batch_id,product_id,qty) VALUES(?,?,?,?)',(bill_id,batch['id'],product_id,take))
  remaining-=take
  if not remaining:break
 if remaining:raise ValueError(f"Inventory update failed for {prod['name']}; bill was not saved.")

def inventory_age(manufacturing_date,today=None):
 try:return (today or datetime.date.today())-datetime.date.fromisoformat(str(manufacturing_date))
 except Exception:return datetime.timedelta(days=0)

def build_end_of_day_data(date):
 summary={'date':date,'bills':0,'total':0.0,'cash':0.0,'online':0.0,'our_total':0.0,'other_total':0.0,'our_qty':0,'other_qty':0,'our_cash':0.0,'our_online':0.0,'other_cash':0.0,'other_online':0.0,'packing_fee':0.0,'packing_cash':0.0,'packing_online':0.0}
 bills=[];our_rows=[];other_rows=[]
 with db() as c:
  raw_bills=[dict(x) for x in c.execute('SELECT * FROM bills WHERE substr(created,1,10)=? ORDER BY created,id',(date,))]
  for b in raw_bills:
   raw_items=[dict(x) for x in c.execute('SELECT product,qty,price,item_type,product_id FROM bill_items WHERE bill_id=?',(b['id'],))]
   normalized=[];our_total=other_total=0.0;our_qty=other_qty=0
   item_sum=sum(int(it['qty'])*float(it['price']) for it in raw_items)
   total=float(b['total'] or 0);cash=float(b['cash'] or 0);online=float(b['online'] or 0)
   extra=round(total-item_sum,2)
   for it in raw_items:
    name=str(it['product']);kind=str(it.get('item_type') or 'Our Item')
    for prefix in ('Our Item - ','Other Item - '):
     if name.startswith(prefix):
      name=name[len(prefix):];break
    if kind not in ('Our Item','Other Item'):kind='Our Item'
    qty=int(it['qty']);rate=float(it['price']);amount=round(qty*rate,2)
    # Allocate payments by line total / bill total so packing charges retain their own cash/online share.
    cash_alloc=round(amount*cash/total,2) if total else 0.0
    online_alloc=round(amount*online/total,2) if total else 0.0
    line={'date':date,'time':str(b.get('created',''))[11:19],'bill_id':b['id'],'customer':b.get('customer_name') or 'Walk-in','product':name,'qty':qty,'rate':rate,'amount':amount,'payment':b.get('payment',''),'cash_alloc':cash_alloc,'online_alloc':online_alloc}
    normalized.append({'name':name,'type':kind,'qty':qty,'rate':rate,'amount':amount,'cash_alloc':cash_alloc,'online_alloc':online_alloc})
    if kind=='Other Item':
     other_total+=amount;other_qty+=qty;summary['other_cash']+=cash_alloc;summary['other_online']+=online_alloc;other_rows.append(line)
    else:
     our_total+=amount;our_qty+=qty;summary['our_cash']+=cash_alloc;summary['our_online']+=online_alloc;our_rows.append(line)
   packing_cash=round(extra*cash/total,2) if total else 0.0
   packing_online=round(extra*online/total,2) if total else 0.0
   bill={'id':b['id'],'created':b.get('created',''),'customer':b.get('customer_name') or 'Walk-in','payment':b.get('payment',''),'total':round(total,2),'cash':round(cash,2),'online':round(online,2),'our_total':round(our_total,2),'our_qty':our_qty,'other_total':round(other_total,2),'other_qty':other_qty,'packing_fee':extra,'packing_cash':packing_cash,'packing_online':packing_online,'items':normalized}
   bills.append(bill)
   summary['bills']+=1;summary['total']+=total;summary['cash']+=cash;summary['online']+=online;summary['our_total']+=our_total;summary['other_total']+=other_total;summary['our_qty']+=our_qty;summary['other_qty']+=other_qty;summary['packing_fee']+=extra;summary['packing_cash']+=packing_cash;summary['packing_online']+=packing_online
 # Credit collections are cash-flow receipts, not new sales. Count today's receipts in Cash/Online only.
 receivings=[]
 for payment in c.execute('SELECT cp.id,cp.bill_id,cp.paid_at,cp.amount,cp.method,cp.note,b.customer_name FROM credit_payments cp JOIN bills b ON b.id=cp.bill_id WHERE substr(cp.paid_at,1,10)=? ORDER BY cp.paid_at,cp.id',(date,)):
  pay=dict(payment); item_details=[]; our_products=[]; other_products=[]
  for it0 in c.execute('SELECT product,qty,price,item_type FROM bill_items WHERE bill_id=? ORDER BY rowid',(pay['bill_id'],)):
   it=dict(it0); original=str(it.get('product') or ''); name=original
   for prefix in ('Our Item - ','Other Item - '):
    if name.startswith(prefix): name=name[len(prefix):]; break
   kind=it.get('item_type') or ('Other Item' if original.startswith('Other Item - ') else 'Our Item')
   item_details.append({'name':name,'type':kind,'qty':int(it.get('qty') or 0),'price':float(it.get('price') or 0)})
   (other_products if kind=='Other Item' else our_products).append(name)
  pay.update({'items':item_details,'our_products':our_products,'other_products':other_products}); receivings.append(pay)
  if pay['method']=='Cash': summary['cash']+=float(pay['amount'] or 0)
  else: summary['online']+=float(pay['amount'] or 0)
 for key in ('total','cash','online','our_total','other_total','our_cash','our_online','other_cash','other_online','packing_fee','packing_cash','packing_online'):
  summary[key]=round(summary[key],2)
 return {'date':date,'summary':summary,'bills':bills,'our_rows':our_rows,'other_rows':other_rows,'receivings':receivings}

# If saved End of Sales snapshots existed before V21, rebuild their stored ledger splits
# once from the now-correctly classified bill rows, while keeping their original generated time.
with db() as c:
 close_marker=c.execute("SELECT value FROM settings WHERE key='menu_based_closings_v21_applied'").fetchone()
 base_marker=c.execute("SELECT value FROM settings WHERE key='menu_based_classification_v21'").fetchone()
 if base_marker and not close_marker:
  closing_dates=[r['sales_date'] for r in c.execute('SELECT sales_date FROM daily_closings').fetchall()]
  for closing_date in closing_dates:
   ledger=build_end_of_day_data(closing_date)
   c.execute('UPDATE daily_closings SET snapshot_json=? WHERE sales_date=?',(json.dumps(ledger,ensure_ascii=False),closing_date))
  c.execute("INSERT INTO settings(key,value) VALUES('menu_based_closings_v21_applied','1')")

def workbook_from_import(import_id):
 try:import openpyxl
 except ImportError:raise ValueError('Excel support is missing. Run INSTALL_REQUIREMENTS.bat once, then restart POS.')
 wb=openpyxl.Workbook();default=wb.active;wb.remove(default)
 with db() as c:
  info=c.execute('SELECT filename FROM excel_imports WHERE id=?',(import_id,)).fetchone()
  if not info:raise ValueError('Imported file not found.')
  names=[r['sheet_name'] for r in c.execute('SELECT sheet_name FROM excel_import_sheets WHERE import_id=? ORDER BY id',(import_id,))]
  if not names:names=[r['sheet_name'] for r in c.execute('SELECT sheet_name FROM excel_import_rows WHERE import_id=? GROUP BY sheet_name ORDER BY MIN(id)',(import_id,))]
  for name in names:
   ws=wb.create_sheet(str(name)[:31] or 'Sheet')
   rows=c.execute('SELECT row_number,row_json FROM excel_import_rows WHERE import_id=? AND sheet_name=? ORDER BY row_number',(import_id,name)).fetchall()
   for row in rows:
    values=json.loads(row['row_json'])
    for col,value in enumerate(values,1):ws.cell(row=int(row['row_number']),column=col,value=value)
   ws.freeze_panes='A1'
 buf=io.BytesIO();wb.save(buf);return buf.getvalue(),str(info['filename'])

def extract_product_list(filename,raw):
 ext=os.path.splitext(filename)[1].lower(); textdata=''
 if ext in ('.txt','.text','.md','.log','.csv'):
  try:textdata=raw.decode('utf-8-sig')
  except UnicodeDecodeError:textdata=raw.decode('latin-1')
 elif ext=='.pdf':
  try:
   import fitz
   doc=fitz.open(stream=raw,filetype='pdf')
   pages=[]
   for page in doc:
    page_text=page.get_text('text') or ''
    if not page_text.strip():
     try:
      import pytesseract
      from PIL import Image
      pix=page.get_pixmap(matrix=fitz.Matrix(2,2),alpha=False)
      img=Image.open(io.BytesIO(pix.tobytes('png')))
      page_text=pytesseract.image_to_string(img)
     except Exception:pass
    pages.append(page_text)
   doc.close();textdata='\n'.join(pages)
  except ImportError:raise ValueError('PDF support is missing. Run INSTALL_REQUIREMENTS.bat once and try again.')
  except Exception as ex:raise ValueError('Could not read this PDF. Make sure it is a valid PDF file.')
 elif ext in ('.png','.jpg','.jpeg','.webp','.bmp','.tif','.tiff'):
  try:
   import pytesseract
   from PIL import Image,ImageOps,ImageEnhance
   img=Image.open(io.BytesIO(raw)).convert('RGB')
   if max(img.size)>2600:img.thumbnail((2600,2600))
   img=ImageEnhance.Contrast(ImageOps.grayscale(img)).enhance(1.5)
   textdata=pytesseract.image_to_string(img)
  except Exception as ex:
   raise ValueError('Image OCR needs Tesseract OCR installed on Windows. Install Tesseract, then restart POS. Error: '+str(ex)[:180])
 else:raise ValueError('Supported formats: .txt, .text, .md, .log, .csv, .pdf, .png, .jpg, .jpeg, .webp, .bmp, .tif and .tiff.')
 if not textdata.strip():raise ValueError('No readable text found. For a photo/image, check that Tesseract OCR is installed and the product names/prices are clear.')
 # Parse common price-list lines, keeping a heading as the current category.
 entries=[]; category='Imported Products'; ignored=[]
 price_re=re.compile(r'(?:₹|rs\.?\s*)\s*([0-9]{1,7}(?:[,.][0-9]{1,2})?)|([0-9]{1,7}(?:[,.][0-9]{1,2})?)\s*(?:/-|rs\.?|rupees?)?',re.I)
 for rawline in textdata.splitlines():
  line=rawline.strip().strip('|•·*\t ')
  if not line or len(line)>240:continue
  line=re.sub(r'^\s*(?:[-•*]|\d+[.)])\s*','',line).strip()
  matches=list(price_re.finditer(line))
  if not matches:
   # Ignore obvious document titles and instructions; otherwise treat short lines as category headings.
   if len(line)<=65 and not re.search(r'\b(price list|menu|the cream studio|total|subtotal|gst|tax|date|phone|contact|address|item name|product name)\b',line,re.I):
    category=line.rstrip(':').strip()
   continue
  m=matches[-1]; amount=m.group(1) or m.group(2)
  try:price=float(amount.replace(',',''))
  except ValueError:continue
  if not 0<=price<=1000000:continue
  name=(line[:m.start()]+line[m.end():]).strip(' -:|\t.,')
  name=re.sub(r'\s{2,}',' ',name).strip()
  # Remove table separators and trailing quantity/weight notes only when they are standalone clutter.
  name=re.sub(r'\s*[|]\s*',' ',name).strip()
  if not name or len(name)>150:continue
  entries.append({'category':category[:100] or 'Imported Products','name':name,'price':round(price,2),'source_line':line[:240]})
 if not entries:raise ValueError('Could not find any product-name + price lines. Try lines like "Chocolate Cake - ₹250" or "Cookies, 140".')
 # Collapse exact same-category/name duplicates but explicitly report them for review.
 def norm(value):return re.sub(r'[^a-z0-9]+','',str(value or '').casefold())
 unique={};duplicates=[]
 for e in entries:
  key=(norm(e['category']),norm(e['name']))
  if key in unique:
   prior=unique[key]
   group=next((d for d in duplicates if d['key']==key),None)
   if group is None:
    group={'key':key,'category':prior['category'],'name':prior['name'],'occurrences':2,'prices':[prior['price'],e['price']],'source_lines':[prior['source_line'],e['source_line']]}
    duplicates.append(group)
   else:
    group['occurrences']+=1;group['prices'].append(e['price']);group['source_lines'].append(e['source_line'])
   prior.setdefault('duplicate_count',1);prior['duplicate_count']+=1
   prior.setdefault('duplicate_prices',[prior['price']]);prior['duplicate_prices'].append(e['price'])
   # Do not silently decide between conflicting prices; keep first value for the user to review.
  else:
   unique[key]=dict(e)
 # Same title in different categories can be intentional (e.g. Chocolate pastry vs hot chocolate), so flag, don't merge.
 by_name={}
 for e in unique.values():by_name.setdefault(norm(e['name']),[]).append(e)
 cross_category_duplicates=[]
 for group in by_name.values():
  cats=sorted(set(e['category'] for e in group))
  if len(group)>1 and len(cats)>1:
   cross_category_duplicates.append({'name':group[0]['name'],'categories':cats})
 for d in duplicates:d.pop('key',None)
 return list(unique.values()),textdata[:1200],duplicates,cross_category_duplicates

class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def send(self,status,data,typ='application/json'):
  raw=(json.dumps(data,ensure_ascii=False).encode() if typ=='application/json' else data);self.send_response(status);self.send_header('Content-Type',typ+'; charset=utf-8');self.send_header('Content-Length',str(len(raw)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(raw)
 def authorized(self):return self.headers.get('X-TCS-Token')==TOKEN
 def do_GET(self):
  p=urlparse(self.path).path
  if p=='/':return self.send(200,open(os.path.join(ROOT,'index.html'),'rb').read(),'text/html')
  if p=='/logo.png':
   logo_path=os.path.join(ROOT,'logo.png')
   if os.path.isfile(logo_path):return self.send(200,open(logo_path,'rb').read(),'image/png')
   return self.send(404,{'error':'Logo file not found. Keep logo.png beside server.py.'})
  if p=='/api/backup':
   if not self.authorized():return self.send(403,{'error':'Unauthorized'})
   # Create a consistent SQLite snapshot. This includes committed WAL data and does not modify the live DB.
   with tempfile.TemporaryDirectory(prefix='tcs_pos_backup_') as td:
    snapshot=os.path.join(td,'tcs_pos.db')
    with sqlite3.connect(DB,timeout=30) as source:
     with sqlite3.connect(snapshot) as target:
      source.backup(target)
      check=target.execute('PRAGMA integrity_check').fetchone()[0]
      if check!='ok':return self.send(500,{'error':'Database integrity check failed; backup was not created.'})
    manifest={'created_at':datetime.datetime.now().astimezone().isoformat(timespec='seconds'),'application':'The Cream Studio POS','database_integrity_check':'ok','files':{},'note':'Restore only when POS is closed. Keep a second copy on a different drive.'}
    mem=io.BytesIO()
    core_files=('server.py','catalog_source.py','index.html','logo.png','requirements.txt','README.txt','START_POS.bat','INSTALL_REQUIREMENTS.bat','backup_pos.py','BACKUP_POS.bat')
    with zipfile.ZipFile(mem,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
     z.write(snapshot,'tcs_pos.db')
     manifest['files']['tcs_pos.db']={'size_bytes':os.path.getsize(snapshot),'sha256':hashlib.sha256(open(snapshot,'rb').read()).hexdigest()}
     for name in core_files:
      fp=os.path.join(ROOT,name)
      if os.path.isfile(fp):
       with open(fp,'rb') as f: raw=f.read()
       z.writestr(name,raw)
       manifest['files'][name]={'size_bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
     # Preserve optional app-owned files, but never recursively include backups or virtual environments.
     for folder_name in ('uploads','exports','attachments','data'):
      folder=os.path.join(ROOT,folder_name)
      if os.path.isdir(folder):
       for current,dirs,files in os.walk(folder):
        dirs[:]=[d for d in dirs if d not in ('.venv','__pycache__','backups')]
        for name in files:
         fp=os.path.join(current,name); arc=os.path.relpath(fp,ROOT).replace(os.sep,'/')
         with open(fp,'rb') as f: raw=f.read()
         z.writestr(arc,raw);manifest['files'][arc]={'size_bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
     z.writestr('backup_manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
    payload=mem.getvalue()
   filename='TCS_POS_FULL_BACKUP_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'.zip'
   self.send_response(200);self.send_header('Content-Type','application/zip');self.send_header('Content-Length',str(len(payload)));self.send_header('Content-Disposition','attachment; filename="'+filename+'"');self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(payload);return
  if p=='/api/products':
   with db() as c:
    rows=[dict(x) for x in c.execute("SELECT p.*,CASE WHEN EXISTS(SELECT 1 FROM inventory_batches ib WHERE ib.product_id=p.id) THEN 1 ELSE 0 END AS inventory_tracked,COALESCE((SELECT SUM(ib.qty_remaining) FROM inventory_batches ib WHERE ib.product_id=p.id),0) AS stock_qty FROM products p WHERE p.active=1 ORDER BY p.category,p.name")]
   for row in rows:
    managed=is_inventory_managed_product(row)
    row['inventory_tracked']=bool(row['inventory_tracked']) if managed else False
    row['stock_qty']=int(row['stock_qty'] or 0) if managed else 0
    row['inventory_managed']=managed
    row['out_of_stock']=bool(managed and (not row['inventory_tracked'] or row['stock_qty']<=0))
   return self.send(200,rows)
  if p=='/api/credit-ledger':
   if not self.authorized():return self.send(403,{'error':'Unauthorized'})
   with db() as c:
    bills=[dict(x) for x in c.execute("SELECT id,created,customer_name,total,credit,payment FROM bills WHERE payment IN ('Credit','Split') AND COALESCE(credit,0)>0 ORDER BY created DESC,id DESC")]
    for b in bills:
     b['items']=[dict(x) for x in c.execute('SELECT product,qty,price FROM bill_items WHERE bill_id=? ORDER BY rowid',(b['id'],))]
     payments=[dict(x) for x in c.execute('SELECT id,paid_at,amount,method,note FROM credit_payments WHERE bill_id=? ORDER BY id',(b['id'],))]
     b['payments']=payments;b['paid']=round(sum(float(x['amount']) for x in payments),2);b['balance']=round(max(0,float(b.get('credit') or b['total'])-b['paid']),2)
   return self.send(200,bills)
  if p=='/api/settings':
   with db() as c: value=float(c.execute("SELECT value FROM settings WHERE key='packing_charge'").fetchone()[0])
   return self.send(200,{'packing_charge':value})
  if p=='/api/stats':
   today=datetime.date.today().isoformat()
   with db() as c:
    r=dict(c.execute('SELECT COUNT(*) bills,COALESCE(SUM(total),0) total,COALESCE(SUM(cash),0) cash,COALESCE(SUM(online),0) online FROM bills WHERE substr(created,1,10)=?',(today,)).fetchone())
    received=c.execute("SELECT COALESCE(SUM(CASE WHEN method='Cash' THEN amount ELSE 0 END),0) received_cash,COALESCE(SUM(CASE WHEN method='Online' THEN amount ELSE 0 END),0) received_online FROM credit_payments WHERE substr(paid_at,1,10)=?",(today,)).fetchone()
    r['received_cash']=round(float(received['received_cash'] or 0),2);r['received_online']=round(float(received['received_online'] or 0),2)
    r['cash']=round(float(r['cash'] or 0)+r['received_cash'],2);r['online']=round(float(r['online'] or 0)+r['received_online'],2)
    imp=c.execute('SELECT COUNT(*) files,COALESCE(SUM(row_count),0) rows FROM excel_imports').fetchone();r['import_files']=imp['files'];r['import_rows']=imp['rows']
   return self.send(200,r)
  if p=='/api/sales/end-of-day':
   if not self.authorized():return self.send(403,{'error':'Unauthorized'})
   qs=parse_qs(urlparse(self.path).query);date=(qs.get('date') or [''])[0]
   try:datetime.date.fromisoformat(date)
   except ValueError:return self.send(400,{'error':'Choose a valid date in YYYY-MM-DD format.'})
   ledger=build_end_of_day_data(date)
   with db() as c:existing=c.execute('SELECT generated_at FROM daily_closings WHERE sales_date=?',(date,)).fetchone()
   return self.send(200,{'date':date,'ledger':ledger,'saved':bool(existing),'generated_at':existing['generated_at'] if existing else ''})
  if p=='/api/sales/date':
   if not self.authorized():return self.send(403,{'error':'Unauthorized'})
   qs=parse_qs(urlparse(self.path).query);date=(qs.get('date') or [''])[0]
   try:datetime.date.fromisoformat(date)
   except ValueError:return self.send(400,{'error':'Choose a valid date in YYYY-MM-DD format.'})
   with db() as c:
    bills=[dict(x) for x in c.execute('SELECT * FROM bills WHERE substr(created,1,10)=? ORDER BY created,id',(date,))]
    summary={'bills':len(bills),'total':0.0,'cash':0.0,'online':0.0,'our_total':0.0,'other_total':0.0,'our_qty':0,'other_qty':0,'packing_fee':0.0}
    for bill in bills:
     raw_items=[dict(x) for x in c.execute('SELECT product,qty,price,item_type,product_id FROM bill_items WHERE bill_id=?',(bill['id'],))]
     items=[];our_total=other_total=0.0;our_qty=other_qty=0
     for it in raw_items:
      name=it['product'];kind=it.get('item_type') or 'Our Item'
      for prefix in ('Our Item - ','Other Item - '):
       if name.startswith(prefix):
        name=name[len(prefix):];break
      qty=int(it['qty']);price=float(it['price']);line=round(price*qty,2)
      if kind=='Other Item':other_total+=line;other_qty+=qty
      else:our_total+=line;our_qty+=qty
      items.append({'name':name,'qty':qty,'price':price,'type':kind,'line_total':line})
     packing_fee=round(float(bill['total'])+float(bill.get('discount_amount') or 0)-our_total-other_total,2)
     bill.update({'items':items,'our_total':round(our_total,2),'other_total':round(other_total,2),'our_qty':our_qty,'other_qty':other_qty,'packing_fee':packing_fee})
     for k,v in [('total',bill['total']),('cash',bill['cash']),('online',bill['online']),('our_total',our_total),('other_total',other_total),('our_qty',our_qty),('other_qty',other_qty),('packing_fee',packing_fee)]:summary[k]+=v
   for key in ('total','cash','online','our_total','other_total','packing_fee'):summary[key]=round(summary[key],2)
   return self.send(200,{'date':date,'summary':summary,'bills':bills})
  if p=='/api/ledger':
   if not self.authorized():return self.send(403,{'error':'Unauthorized'})
   qs=parse_qs(urlparse(self.path).query);kind=(qs.get('type') or [''])[0];date_from=(qs.get('from') or [''])[0];date_to=(qs.get('to') or [''])[0]
   if kind not in ('Our Item','Other Item'):return self.send(400,{'error':'Choose Our Item or Other Item ledger.'})
   for date_value in (date_from,date_to):
    if date_value:
     try:datetime.date.fromisoformat(date_value)
     except ValueError:return self.send(400,{'error':'Date filters must use YYYY-MM-DD format.'})
   if date_from and date_to and date_from>date_to:return self.send(400,{'error':'From date cannot be after To date.'})
   conditions=[];params=[]
   if date_from:conditions.append('substr(b.created,1,10)>=?');params.append(date_from)
   if date_to:conditions.append('substr(b.created,1,10)<=?');params.append(date_to)
   where=(' WHERE '+' AND '.join(conditions)) if conditions else ''
   rows=[]
   with db() as c:
    bills=[dict(x) for x in c.execute('SELECT b.id,b.created,b.payment,b.total,b.cash,b.online,b.customer_name FROM bills b'+where+' ORDER BY b.created,b.id',params)]
    for bill in bills:
     its=[dict(x) for x in c.execute('SELECT product,qty,price,item_type,product_id FROM bill_items WHERE bill_id=?',(bill['id'],))]
     item_sum=sum(int(it['qty'])*float(it['price']) for it in its)
     for it in its:
      name=it['product'];item_kind=it.get('item_type') or 'Our Item'
      for prefix in ('Our Item - ','Other Item - '):
       if name.startswith(prefix):
        name=name[len(prefix):];break
      if item_kind!=kind:continue
      qty=int(it['qty']);rate=float(it['price']);amount=round(qty*rate,2)
      cash_alloc=round(amount*float(bill['cash'])/item_sum,2) if item_sum else 0.0
      online_alloc=round(amount*float(bill['online'])/item_sum,2) if item_sum else 0.0
      rows.append({'date':bill['created'],'bill_id':bill['id'],'customer':bill.get('customer_name',''),'product':name,'qty':qty,'rate':rate,'amount':amount,'payment':bill['payment'],'cash_alloc':cash_alloc,'online_alloc':online_alloc})
   return self.send(200,{'type':kind,'from':date_from,'to':date_to,'rows':rows})
  if p=='/api/bills':
   with db() as c:
    bills=[dict(x) for x in c.execute('SELECT * FROM bills ORDER BY id DESC LIMIT 100')]
    for bill in bills:
     raw_items=[dict(x) for x in c.execute('SELECT product,qty,price,item_type,product_id FROM bill_items WHERE bill_id=?',(bill['id'],))]
     items=[];our_total=other_total=0.0;our_qty=other_qty=0
     for it in raw_items:
      name=it['product'];kind=it.get('item_type') or 'Our Item'
      for prefix in ('Our Item - ','Other Item - '):
       if name.startswith(prefix):
        name=name[len(prefix):];break
      line=round(float(it['price'])*int(it['qty']),2)
      if kind=='Other Item':other_total+=line;other_qty+=int(it['qty'])
      else:our_total+=line;our_qty+=int(it['qty'])
      items.append({'name':name,'qty':int(it['qty']),'price':float(it['price']),'type':kind,'line_total':line,'product_id':it.get('product_id')})
     bill.update({'items':items,'our_total':round(our_total,2),'other_total':round(other_total,2),'our_qty':our_qty,'other_qty':other_qty})
    # Credit collections are shown on their actual received date and include the original bill's product details.
    for payment in c.execute('SELECT cp.id,cp.bill_id,cp.paid_at,cp.amount,cp.method,cp.note,b.customer_name FROM credit_payments cp JOIN bills b ON b.id=cp.bill_id ORDER BY cp.id DESC LIMIT 500'):
     pay=dict(payment); receiving_items=[];our_products=[];other_products=[]
     for it0 in c.execute('SELECT product,qty,price,item_type FROM bill_items WHERE bill_id=? ORDER BY rowid',(pay['bill_id'],)):
      it=dict(it0); original=str(it.get('product') or '');name=original
      for prefix in ('Our Item - ','Other Item - '):
       if name.startswith(prefix): name=name[len(prefix):];break
      kind=it.get('item_type') or ('Other Item' if original.startswith('Other Item - ') else 'Our Item')
      receiving_items.append({'name':name,'qty':int(it.get('qty') or 0),'price':float(it.get('price') or 0),'type':kind,'line_total':round(int(it.get('qty') or 0)*float(it.get('price') or 0),2)})
      (other_products if kind=='Other Item' else our_products).append(name)
     bills.append({'id':f"R{pay['id']}",'created':pay['paid_at'],'customer_name':pay.get('customer_name') or 'Customer','payment':'Credit Received','cash':pay['amount'] if pay['method']=='Cash' else 0,'online':pay['amount'] if pay['method']=='Online' else 0,'credit':0,'total':0,'our_total':0,'other_total':0,'our_qty':0,'other_qty':0,'items':receiving_items,'is_receiving':True,'receiving_amount':pay['amount'],'receiving_method':pay['method'],'original_bill_id':pay['bill_id'],'receiving_note':pay.get('note') or '', 'our_products':our_products,'other_products':other_products})
   return self.send(200,bills)
  if p=='/api/sales/month-performance':
   if not self.authorized():return self.send(403,{'error':'Unauthorized'})
   qs=parse_qs(urlparse(self.path).query);month=(qs.get('month') or [''])[0]
   try:
    datetime.datetime.strptime(month,'%Y-%m')
   except ValueError:return self.send(400,{'error':'Choose a valid month in YYYY-MM format.'})
   ranking={}
   with db() as c:
    rows=[dict(x) for x in c.execute("SELECT bi.product,bi.qty,bi.price,bi.item_type,b.payment,b.created FROM bill_items bi JOIN bills b ON b.id=bi.bill_id WHERE substr(b.created,1,7)=? ORDER BY b.created,b.id",(month,))]
   for row in rows:
    original=str(row.get('product') or '').strip();name=original;prefix_kind=None
    for prefix,kind0 in (('Our Item - ','Our Item'),('Other Item - ','Other Item')):
     if name.startswith(prefix):name=name[len(prefix):];prefix_kind=kind0;break
    kind=row.get('item_type') if row.get('item_type') in ('Our Item','Other Item') else (prefix_kind or 'Other Item')
    key=(kind,normalized_product_name(name))
    if not key[1]:continue
    entry=ranking.setdefault(key,{'name':name,'type':kind,'qty':0,'value':0.0})
    qty=max(0,int(row.get('qty') or 0));entry['qty']+=qty
    if row.get('payment')!='Delivered on Zomato':entry['value']+=float(row.get('price') or 0)*qty
   result=sorted(ranking.values(),key=lambda x:(-x['qty'],-x['value'],x['name'].casefold()))
   for row in result:row['value']=round(row['value'],2)
   return self.send(200,{'month':month,'best':result[0] if result else None,'ranking':result,'products_sold':len(result)})
  if p=='/api/product-performance':
   # Read-only all-time ranking. Quantities include stock-only Zomato deliveries;
   # sales value excludes them because no payment amount is recorded for those entries.
   with db() as c:
    current=[dict(x) for x in c.execute("SELECT id,category,name,price,item_type,active FROM products WHERE active=1 ORDER BY name")]
    sales=[dict(x) for x in c.execute("SELECT bi.bill_id,bi.product,bi.qty,bi.price,bi.item_type,bi.product_id,b.created,b.payment FROM bill_items bi JOIN bills b ON b.id=bi.bill_id ORDER BY b.created,b.id")]
   stats={};
   def perf_key(kind,name):
    cleaned=str(name or '').strip()
    for prefix in ('Our Item - ','Other Item - '):
     if cleaned.startswith(prefix):cleaned=cleaned[len(prefix):]
    return (kind,normalized_product_name(cleaned))
   for prod in current:
    kind=prod.get('item_type') if prod.get('item_type') in ('Our Item','Other Item') else 'Other Item'
    name=str(prod.get('name') or '').strip();key=perf_key(kind,name)
    if not key[1]:continue
    entry=stats.setdefault(key,{'name':name,'category':prod.get('category') or '', 'item_type':kind,'qty_sold':0,'sales_value':0.0,'bill_ids':set(),'last_sold':''})
    if not entry['category']:entry['category']=prod.get('category') or ''
   for sale in sales:
    original=str(sale.get('product') or '').strip();name=original
    prefix_kind=None
    for prefix,kind0 in (('Our Item - ','Our Item'),('Other Item - ','Other Item')):
     if name.startswith(prefix):name=name[len(prefix):];prefix_kind=kind0;break
    kind=sale.get('item_type') if sale.get('item_type') in ('Our Item','Other Item') else (prefix_kind or 'Other Item')
    key=perf_key(kind,name)
    if not key[1]:continue
    entry=stats.setdefault(key,{'name':name,'category':'','item_type':kind,'qty_sold':0,'sales_value':0.0,'bill_ids':set(),'last_sold':''})
    entry['qty_sold']+=max(0,int(sale.get('qty') or 0))
    if sale.get('payment')!='Delivered on Zomato':entry['sales_value']+=float(sale.get('price') or 0)*max(0,int(sale.get('qty') or 0))
    entry['bill_ids'].add(sale.get('bill_id'))
    created=str(sale.get('created') or '')
    if created>entry['last_sold']:entry['last_sold']=created
   output={'Our Item':[],'Other Item':[]}
   for (kind,norm),entry in stats.items():
    row={'name':entry['name'],'category':entry['category'],'item_type':kind,'qty_sold':int(entry['qty_sold']),'sales_value':round(entry['sales_value'],2),'bill_count':len(entry['bill_ids']),'last_sold':entry['last_sold']}
    output[kind].append(row)
   for kind in output:
    output[kind].sort(key=lambda x:(-x['qty_sold'],-x['sales_value'],x['name'].casefold()))
   summary={'qty':sum(x['qty_sold'] for rows in output.values() for x in rows),'our_value':round(sum(x['sales_value'] for x in output['Our Item']),2),'other_value':round(sum(x['sales_value'] for x in output['Other Item']),2)}
   def side_summary(rows):return {'qty':sum(x['qty_sold'] for x in rows),'value':round(sum(x['sales_value'] for x in rows),2),'products':len(rows)}
   return self.send(200,{'our_items':output['Our Item'],'other_items':output['Other Item'],'summary':summary,'our_summary':side_summary(output['Our Item']),'other_summary':side_summary(output['Other Item'])})
  if p=='/api/other-inventory':
   if not self.authorized():return self.send(403,{'error':'Unauthorized'})
   today=datetime.date.today();products_out=[]
   with db() as c:
    folders=[dict(x) for x in c.execute('SELECT id,name,parent_id,active FROM other_inventory_folders WHERE active=1 ORDER BY parent_id IS NOT NULL,name')]
    base=[dict(x) for x in c.execute("SELECT p.id,p.category,p.name,p.price,p.item_type,p.active,CASE WHEN EXISTS(SELECT 1 FROM inventory_batches ib WHERE ib.product_id=p.id) THEN 1 ELSE 0 END AS inventory_tracked,COALESCE((SELECT SUM(ib.qty_remaining) FROM inventory_batches ib WHERE ib.product_id=p.id),0) AS stock_qty FROM products p WHERE p.active=1 AND p.item_type='Other Item' ORDER BY p.category,p.name")]
    base=[prod for prod in base if is_inventory_managed_product(prod)]
    for prod in base:
     lots=[dict(x) for x in c.execute('SELECT id,manufacturing_date,qty_received,qty_remaining,created_at FROM inventory_batches WHERE product_id=? ORDER BY manufacturing_date,id',(prod['id'],))]
     for lot in lots:lot['age_days']=inventory_age(lot['manufacturing_date'],today).days
     prod['inventory_tracked']=bool(prod['inventory_tracked']);prod['stock_qty']=int(prod['stock_qty'] or 0);prod['lots']=lots
     prod['status']='Out of stock' if prod['inventory_tracked'] and prod['stock_qty']<=0 else ('In stock' if prod['inventory_tracked'] else 'Not tracked yet')
     products_out.append(prod)
   return self.send(200,{'date':today.isoformat(),'folders':folders,'products':products_out})
  if p=='/api/inventory':
   if not self.authorized():return self.send(403,{'error':'Unauthorized'})
   today=datetime.date.today();products_out=[];alerts=[]
   with db() as c:
    base=[dict(x) for x in c.execute("SELECT p.id,p.category,p.name,p.price,p.item_type,p.active,CASE WHEN EXISTS(SELECT 1 FROM inventory_batches ib WHERE ib.product_id=p.id) THEN 1 ELSE 0 END AS inventory_tracked,COALESCE((SELECT SUM(ib.qty_remaining) FROM inventory_batches ib WHERE ib.product_id=p.id),0) AS stock_qty FROM products p WHERE p.active=1 AND p.item_type='Our Item' ORDER BY p.category,p.name")]
    base=[prod for prod in base if is_inventory_managed_product(prod)]
    for prod in base:
     lots=[dict(x) for x in c.execute('SELECT id,manufacturing_date,qty_received,qty_remaining,created_at FROM inventory_batches WHERE product_id=? ORDER BY manufacturing_date,id',(prod['id'],))]
     for lot in lots:
      age=inventory_age(lot['manufacturing_date'],today).days;lot['age_days']=age
      if int(lot['qty_remaining'])>0 and age>=3:
       alerts.append({'product_id':prod['id'],'category':prod['category'],'name':prod['name'],'manufacturing_date':lot['manufacturing_date'],'qty_remaining':int(lot['qty_remaining']),'age_days':age})
     prod['inventory_tracked']=bool(prod['inventory_tracked']);prod['stock_qty']=int(prod['stock_qty'] or 0);prod['lots']=lots
     prod['status']='Out of stock' if prod['inventory_tracked'] and prod['stock_qty']<=0 else ('In stock' if prod['inventory_tracked'] else 'Not tracked yet')
     products_out.append(prod)
   alerts.sort(key=lambda a:(-a['age_days'],a['manufacturing_date'],a['name'].casefold()))
   return self.send(200,{'date':today.isoformat(),'products':products_out,'alerts':alerts,'alert_count':len(alerts),'managed_categories':sorted(INVENTORY_MANAGED_CATEGORIES),'policy':'Inventory is limited to Our Item products in Bento Cake, 250 GM Cake, 500 GM Cake, Pastry, Desserts, Cheesecake, and Hot Items. New products added to these categories are included automatically. A tracked product with zero stock is paused until new stock is entered.'})
  if p=='/api/inventory/alerts':
   if not self.authorized():return self.send(403,{'error':'Unauthorized'})
   today=datetime.date.today();alerts=[]
   with db() as c:
    lots=c.execute("SELECT p.id AS product_id,p.category,p.name,p.item_type,b.manufacturing_date,b.qty_remaining FROM inventory_batches b JOIN products p ON p.id=b.product_id WHERE p.active=1 AND p.item_type='Our Item' AND b.qty_remaining>0 ORDER BY b.manufacturing_date,p.name").fetchall()
   lots=[lot for lot in lots if is_inventory_managed_product(lot)]
   for lot in lots:
    age=inventory_age(lot['manufacturing_date'],today).days
    if age>=3:alerts.append({'product_id':lot['product_id'],'category':lot['category'],'name':lot['name'],'manufacturing_date':lot['manufacturing_date'],'qty_remaining':int(lot['qty_remaining']),'age_days':age})
   return self.send(200,{'date':today.isoformat(),'alerts':alerts,'alert_count':len(alerts)})
  if p=='/api/excel/imports':
   if not self.authorized():return self.send(403,{'error':'Unauthorized'})
   with db() as c: rows=[dict(x) for x in c.execute("SELECT id,filename,imported_at,row_count,CASE WHEN source_data IS NOT NULL AND length(source_data)>0 THEN 1 ELSE 0 END AS source_available FROM excel_imports ORDER BY id DESC LIMIT 100")]
   for row in rows:row['source_available']=bool(row['source_available'])
   return self.send(200,rows)
  if p.startswith('/api/excel/imports/'):
   if not self.authorized():return self.send(403,{'error':'Unauthorized'})
   parts=p.strip('/').split('/')
   try:iid=int(parts[3])
   except (ValueError,IndexError):return self.send(400,{'error':'Invalid import ID'})
   suffix=parts[4] if len(parts)>4 else ''
   with db() as c:
    info=c.execute("SELECT id,filename,imported_at,row_count,source_data,source_ext FROM excel_imports WHERE id=?",(iid,)).fetchone()
    if not info:return self.send(404,{'error':'Imported file not found'})
    sheet_meta_rows=[dict(x) for x in c.execute('SELECT sheet_name,max_row,max_column,nonempty_rows FROM excel_import_sheets WHERE import_id=? ORDER BY id',(iid,))]
    sheets=[x['sheet_name'] for x in sheet_meta_rows] or [x['sheet_name'] for x in c.execute('SELECT sheet_name FROM excel_import_rows WHERE import_id=? GROUP BY sheet_name ORDER BY MIN(id)',(iid,))]
    if suffix=='source':source_data=info['source_data'];source_ext=info['source_ext'] or os.path.splitext(info['filename'])[1].lower()
    elif suffix=='data':
     qs=parse_qs(urlparse(self.path).query);sheet=(qs.get('sheet') or [''])[0]
     if not sheet:sheet=sheets[0] if sheets else ''
     if sheet not in sheets:return self.send(400,{'error':'Choose a valid worksheet.'})
     try:offset=max(0,int((qs.get('offset') or ['0'])[0]));limit=max(1,min(500,int((qs.get('limit') or ['200'])[0])))
     except ValueError:return self.send(400,{'error':'Invalid row paging values.'})
     meta=next((x for x in sheet_meta_rows if x['sheet_name']==sheet),None)
     nonempty_rows=int(meta['nonempty_rows']) if meta else int(c.execute('SELECT COUNT(*) FROM excel_import_rows WHERE import_id=? AND sheet_name=?',(iid,sheet)).fetchone()[0])
     total=int(meta['max_row']) if meta else int(c.execute('SELECT COALESCE(MAX(row_number),0) FROM excel_import_rows WHERE import_id=? AND sheet_name=?',(iid,sheet)).fetchone()[0])
     rows=[dict(x) for x in c.execute('SELECT sheet_name,row_number,row_json FROM excel_import_rows WHERE import_id=? AND sheet_name=? AND row_number>? AND row_number<=? ORDER BY row_number',(iid,sheet,offset,offset+limit))]
     # Use stored worksheet dimensions, or infer them for legacy imports.
     max_cols=int(meta['max_column']) if meta else 0
     if not meta:
      for x in c.execute('SELECT row_json FROM excel_import_rows WHERE import_id=? AND sheet_name=?',(iid,sheet)):
       try:max_cols=max(max_cols,len(json.loads(x['row_json'])))
       except Exception:pass
     fileinfo={'id':info['id'],'filename':info['filename'],'imported_at':info['imported_at'],'row_count':info['row_count'],'source_available':bool(info['source_data'])}
    else:
     rows=[dict(x) for x in c.execute('SELECT sheet_name,row_number,row_json FROM excel_import_rows WHERE import_id=? ORDER BY id LIMIT 500',(iid,))]
     fileinfo={'id':info['id'],'filename':info['filename'],'imported_at':info['imported_at'],'row_count':info['row_count'],'source_available':bool(info['source_data'])}
   if suffix=='source':
    if source_data:
     mime=mimetypes.guess_type('uploaded'+source_ext)[0] or 'application/octet-stream'
     return self.send(200,bytes(source_data),mime)
    try:rebuilt,oldname=workbook_from_import(iid)
    except Exception as ex:return self.send(500,{'error':str(ex)})
    return self.send(200,rebuilt,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
   if suffix=='data':
    for row in rows:
     try:row['values']=json.loads(row.pop('row_json'))
     except Exception:row['values']=[]
    return self.send(200,{'file':fileinfo,'sheets':sheets,'sheet':sheet,'rows':rows,'offset':offset,'shown':min(limit,max(0,total-offset)),'sheet_row_count':total,'nonempty_row_count':nonempty_rows,'column_count':max_cols})
   for row in rows:
    try:row['values']=json.loads(row.pop('row_json'))
    except Exception:row['values']=[]
   return self.send(200,{'file':fileinfo,'sheets':sheets,'rows':rows,'shown':len(rows),'truncated':info['row_count']>len(rows)})
  if p=='/api/export/end-of-day':
   if not self.authorized():return self.send(403,{'error':'Unauthorized'})
   qs=parse_qs(urlparse(self.path).query);date=(qs.get('date') or [''])[0]
   try:datetime.date.fromisoformat(date)
   except ValueError:return self.send(400,{'error':'Choose a valid date in YYYY-MM-DD format.'})
   with db() as c:close=c.execute('SELECT generated_at,snapshot_json FROM daily_closings WHERE sales_date=?',(date,)).fetchone()
   if not close:return self.send(404,{'error':'No saved End of Sales ledger for this date. Open End of Sales and generate/save it first.'})
   try:import openpyxl
   except ImportError:return self.send(500,{'error':'Excel export needs openpyxl. Run INSTALL_REQUIREMENTS.bat once, then restart POS.'})
   ledger=build_end_of_day_data(date);m=ledger['summary'];wb=openpyxl.Workbook();ws=wb.active;ws.title='End of Sales Summary'
   ws.append(['The Cream Studio POS — End of Sales Ledger']);ws.append(['Sales Date',date]);ws.append(['Generated At',close['generated_at']]);ws.append([]);ws.append(['Metric','Amount / Qty']);
   for label,key in [('Bills','bills'),('Our Item Sales (₹)','our_total'),('Our Item Quantity','our_qty'),('Other Item Sales (₹)','other_total'),('Other Item Quantity','other_qty'),('Total Sales (₹)','total'),('Cash Received (₹)','cash'),('Online Received (₹)','online'),('Our Item Cash Allocation (₹)','our_cash'),('Our Item Online Allocation (₹)','our_online'),('Other Item Cash Allocation (₹)','other_cash'),('Other Item Online Allocation (₹)','other_online'),('Packing / Extra Charges (₹)','packing_fee'),('Packing Cash Allocation (₹)','packing_cash'),('Packing Online Allocation (₹)','packing_online')]:ws.append([label,m.get(key,0)])
   bs=wb.create_sheet('Bill Summary');bs.append(['Bill ID','Date/Time','Customer','Payment','Our Item Sales ₹','Our Qty','Other Item Sales ₹','Other Qty','Packing/Extra ₹','Bill Total ₹','Cash ₹','Online ₹'])
   for b in ledger['bills']:bs.append([b['id'],b['created'],b['customer'],b['payment'],b['our_total'],b['our_qty'],b['other_total'],b['other_qty'],b['packing_fee'],b['total'],b['cash'],b['online']])
   rws=wb.create_sheet('Credit Receivings');rws.append(['Received Date/Time','Customer','Original Bill ID','Received Amount ₹','Method','Our Item Products','Other Item Products','Note'])
   for r in ledger.get('receivings',[]):
    rws.append([r.get('paid_at',''),r.get('customer_name') or 'Customer',r.get('bill_id'),r.get('amount',0),r.get('method',''),', '.join(r.get('our_products',[])),', '.join(r.get('other_products',[])),r.get('note','')])
   for title,key in [('Our Item Ledger','our_rows'),('Other Item Ledger','other_rows')]:
    sh=wb.create_sheet(title);sh.append(['Date','Time','Bill ID','Customer','Product','Quantity','Rate ₹','Amount ₹','Payment Mode','Cash Allocated ₹','Online Allocated ₹'])
    for r in ledger[key]:sh.append([r['date'],r['time'],r['bill_id'],r['customer'],r['product'],r['qty'],r['rate'],r['amount'],r['payment'],r['cash_alloc'],r['online_alloc']])
   pws=wb.create_sheet('Cash Online Ledger');pws.append(['Category','Sales ₹','Cash Allocation ₹','Online Allocation ₹','Quantity'])
   pws.append(['Our Item',m['our_total'],m['our_cash'],m['our_online'],m['our_qty']]);pws.append(['Other Item',m['other_total'],m['other_cash'],m['other_online'],m['other_qty']]);pws.append(['Packing / Extra',m['packing_fee'],m['packing_cash'],m['packing_online'],'']);pws.append(['TOTAL',m['total'],m['cash'],m['online'],m['our_qty']+m['other_qty']])
   for sh in wb.worksheets:
    sh.freeze_panes='A2';sh.auto_filter.ref=sh.dimensions
    for col in sh.columns:
     letter=col[0].column_letter;maxlen=max((len(str(cell.value or '')) for cell in col),default=10);sh.column_dimensions[letter].width=min(max(maxlen+2,12),36)
    for row in sh.iter_rows(min_row=1,max_row=1):
     for cell in row:cell.font=openpyxl.styles.Font(bold=True,color='FFFFFF');cell.fill=openpyxl.styles.PatternFill('solid',fgColor='5A382A')
   buf=io.BytesIO();wb.save(buf)
   return self.send(200,buf.getvalue(),'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
  if p=='/api/export':
   if not self.authorized():return self.send(403,{'error':'Unauthorized'})
   try:import openpyxl
   except ImportError:return self.send(500,{'error':'Excel export needs openpyxl. Run INSTALL_REQUIREMENTS.bat once, then restart POS.'})
   wb=openpyxl.Workbook();ws=wb.active;ws.title='Bills Summary'
   ws.append(['Bill ID','Date','Customer','Payment','Bill Total (₹)','Cash (₹)','Online (₹)','Our Item Sales (₹)','Other Item Sales (₹)','Our Item Qty','Other Item Qty','Other Charges / Packing (₹)'])
   detail=wb.create_sheet('Bill Items');detail.append(['Bill ID','Date','Customer','Payment','Item Type','Product','Quantity','Unit Price (₹)','Line Total (₹)'])
   our_ledger=wb.create_sheet('Our Item Ledger');our_ledger.append(['Date','Bill ID','Customer','Product','Quantity','Rate (₹)','Amount (₹)','Payment Mode','Bill Cash (₹)','Bill Online (₹)','Item Cash Allocation (₹)','Item Online Allocation (₹)'])
   other_ledger=wb.create_sheet('Other Item Ledger');other_ledger.append(['Date','Bill ID','Customer','Product','Quantity','Rate (₹)','Amount (₹)','Payment Mode','Bill Cash (₹)','Bill Online (₹)','Item Cash Allocation (₹)','Item Online Allocation (₹)'])
   daily=wb.create_sheet('Daily Ledger');daily.append(['Date','Our Item Sales (₹)','Our Item Qty','Other Item Sales (₹)','Other Item Qty','Item Sales Total (₹)','Bills Count','Cash Received (₹)','Online Received (₹)','Bill Total (₹)'])
   daily_totals={}
   with db() as c:
    bills=[dict(x) for x in c.execute('SELECT id,created,payment,total,cash,online,customer_name FROM bills ORDER BY created,id')]
    for b in bills:
     our=other=0.0;ourq=otherq=0;items=[]
     for it0 in c.execute('SELECT product,qty,price,item_type,product_id FROM bill_items WHERE bill_id=?',(b['id'],)):
      it=dict(it0);kind=it.get('item_type') or 'Our Item';name=it['product']
      for prefix in ('Our Item - ','Other Item - '):
       if name.startswith(prefix):
        name=name[len(prefix):];break
      qty=int(it['qty']);price=float(it['price']);line=round(qty*price,2);items.append((kind,name,qty,price,line))
      if kind=='Other Item':other+=line;otherq+=qty
      else:our+=line;ourq+=qty
      detail.append([b['id'],b['created'],b.get('customer_name',''),b['payment'],kind,name,qty,price,line])
     item_sum=round(our+other,2);extra=round(float(b['total'])-item_sum,2)
     ws.append([b['id'],b['created'],b.get('customer_name',''),b['payment'],b['total'],b['cash'],b['online'],round(our,2),round(other,2),ourq,otherq,extra])
     for kind,name,qty,price,line in items:
      # Allocate the bill's cash/online proportionally across item lines; charges beyond items remain in Bills Summary.
      cash_alloc=round(line*float(b['cash'])/item_sum,2) if item_sum else 0
      online_alloc=round(line*float(b['online'])/item_sum,2) if item_sum else 0
      target=our_ledger if kind=='Our Item' else other_ledger
      target.append([b['created'],b['id'],b.get('customer_name',''),name,qty,price,line,b['payment'],b['cash'],b['online'],cash_alloc,online_alloc])
     date=str(b['created'])[:10]
     d=daily_totals.setdefault(date,{'our':0,'ourq':0,'other':0,'otherq':0,'bills':0,'cash':0,'online':0,'total':0})
     d['our']+=our;d['ourq']+=ourq;d['other']+=other;d['otherq']+=otherq;d['bills']+=1;d['cash']+=float(b['cash']);d['online']+=float(b['online']);d['total']+=float(b['total'])
   for date,d in sorted(daily_totals.items()):
    daily.append([date,round(d['our'],2),d['ourq'],round(d['other'],2),d['otherq'],round(d['our']+d['other'],2),d['bills'],round(d['cash'],2),round(d['online'],2),round(d['total'],2)])
   for sh in wb.worksheets:
    sh.freeze_panes='A2';sh.auto_filter.ref=sh.dimensions
    for col in sh.columns:
     letter=col[0].column_letter;maxlen=max((len(str(cell.value or '')) for cell in col),default=10);sh.column_dimensions[letter].width=min(max(maxlen+2,12),34)
    for cell in sh[1]:cell.font=openpyxl.styles.Font(bold=True,color='FFFFFF');cell.fill=openpyxl.styles.PatternFill('solid',fgColor='5A382A')
   buf=io.BytesIO();wb.save(buf)
   return self.send(200,buf.getvalue(),'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
  return self.send(404,{'error':'Not found'})
 def do_POST(self):
  if not self.authorized():return self.send(403,{'error':'Unauthorized'})
  try:
   n=int(self.headers.get('Content-Length','0'));p=urlparse(self.path).path
   limit=20*1024*1024 if p in ('/api/excel/import','/api/product-list/preview') else 200000
   if n>limit or n<=0:raise ValueError('File too large or invalid request. Excel import limit is 14 MB.')
   body=json.loads(self.rfile.read(n))
   if p=='/api/excel/import':
    filename=os.path.basename(str(body.get('filename','workbook.xlsx')))[:180]
    ext=os.path.splitext(filename)[1].lower()
    if ext not in ('.xlsx','.xlsm','.csv'):raise ValueError('Please choose an .xlsx, .xlsm or .csv file. Old .xls files are not supported; save them as .xlsx first.')
    raw=base64.b64decode(body.get('data',''),validate=True)
    if not raw or len(raw)>14*1024*1024:raise ValueError('File is empty or larger than 14 MB.')
    digest=hashlib.sha256(raw).hexdigest()
    with db() as c:
     existing=c.execute('SELECT id,row_count,source_data FROM excel_imports WHERE file_hash=?',(digest,)).fetchone()
     if existing:
      if not existing['source_data']:
       c.execute('UPDATE excel_imports SET source_data=?,source_ext=? WHERE id=?',(sqlite3.Binary(raw),ext,existing['id']))
      return self.send(200,{'ok':True,'duplicate':True,'id':existing['id'],'rows':existing['row_count'],'message':'This exact file was already imported; no duplicate rows were added. Original file archive is available.'})
    records=[];sheet_meta=[]
    if ext=='.csv':
     textdata=raw.decode('utf-8-sig');csv_rows=list(csv.reader(io.StringIO(textdata)));max_cols=max((len(r) for r in csv_rows),default=0);nonempty=0
     for rn,row in enumerate(csv_rows,1):
      if any(str(v).strip() for v in row):records.append(('CSV',rn,[v for v in row]));nonempty+=1
     sheet_meta.append(('CSV',len(csv_rows),max_cols,nonempty))
    else:
     try:
      import openpyxl
      wb=openpyxl.load_workbook(io.BytesIO(raw),read_only=True,data_only=True)
     except ImportError:raise ValueError('Excel support is missing. Run INSTALL_REQUIREMENTS.bat once and try again.')
     except Exception as ex:raise ValueError('Could not read this Excel file. Check that it is a valid .xlsx/.xlsm workbook.')
     for ws in wb.worksheets:
      nonempty=0;max_row=int(ws.max_row or 0);max_col=int(ws.max_column or 0)
      for rn,row in enumerate(ws.iter_rows(values_only=True),1):
       vals=[v.isoformat() if isinstance(v,(datetime.datetime,datetime.date,datetime.time)) else v for v in row]
       if any(v is not None and str(v).strip() for v in vals):records.append((ws.title[:120],rn,vals));nonempty+=1
      sheet_meta.append((ws.title[:120],max_row,max_col,nonempty))
     wb.close()
    if not records:raise ValueError('No non-empty rows were found in this file.')
    if len(records)>100000:raise ValueError('This workbook has more than 100,000 non-empty rows. Split it into smaller files.')
    imported=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    with db() as c:
     cur=c.execute('INSERT INTO excel_imports(filename,imported_at,row_count,file_hash,source_data,source_ext) VALUES(?,?,?,?,?,?)',(filename,imported,len(records),digest,sqlite3.Binary(raw),ext));iid=cur.lastrowid
     c.executemany('INSERT INTO excel_import_rows(import_id,sheet_name,row_number,row_json) VALUES(?,?,?,?)',[(iid,sh,rn,json.dumps(vals,ensure_ascii=False,default=str)) for sh,rn,vals in records])
     c.executemany('INSERT INTO excel_import_sheets(import_id,sheet_name,max_row,max_column,nonempty_rows) VALUES(?,?,?,?,?)',[(iid,sh,mr,mc,nn) for sh,mr,mc,nn in sheet_meta])
    return self.send(200,{'ok':True,'id':iid,'rows':len(records),'sheets':len(sheet_meta),'filename':filename,'message':"Imported locally. Historical rows are saved separately and do not change today's billing totals."})
   if p=='/api/product-list/preview':
    filename=os.path.basename(str(body.get('filename','product-list.txt')))[:180]
    raw=base64.b64decode(body.get('data',''),validate=True)
    if not raw or len(raw)>14*1024*1024:raise ValueError('File is empty or larger than 14 MB.')
    entries,extracted,duplicates,cross_duplicates=extract_product_list(filename,raw)
    return self.send(200,{'ok':True,'filename':filename,'entries':entries,'count':len(entries),'text_preview':extracted,'duplicates':duplicates,'duplicate_count':len(duplicates),'possible_duplicates':cross_duplicates})
   if p=='/api/product-list/apply':
    entries=body.get('entries',[])
    if not isinstance(entries,list) or not 1<=len(entries)<=2000:raise ValueError('Choose a product list with 1 to 2,000 parsed products.')
    cleaned=[]
    for e in entries:
     cat=str(e.get('category','Imported Products')).strip()[:100];name=str(e.get('name','')).strip()[:150]
     try:price=round(float(e.get('price')),2)
     except (TypeError,ValueError):raise ValueError('Every product must have a valid price.')
     kind=str(e.get('item_type','')).strip()
     if not cat or not name or not __import__('math').isfinite(price) or not 0<=price<=1000000:raise ValueError('Invalid product/category/price in the preview.')
     if kind not in ('Our Item','Other Item'):raise ValueError(f'Choose Our Item or Other Item for every menu item, including existing products: {name}')
     cleaned.append((cat,name,price,kind))
    seen_keys=set()
    for cat,name,price,kind in cleaned:
     key=(re.sub(r'[^a-z0-9]+','',cat.casefold()),re.sub(r'[^a-z0-9]+','',name.casefold()))
     if key in seen_keys:raise ValueError(f'Duplicate product remains in the reviewed menu: {name} ({cat}). Rename or remove the duplicate row before applying.')
     seen_keys.add(key)
    added=updated=0;new_names=[];changed_types=0
    with db() as c:
     for cat,name,price,kind in cleaned:
      existing=c.execute('SELECT id,price,active,item_type FROM products WHERE lower(trim(category))=lower(trim(?)) AND lower(trim(name))=lower(trim(?)) ORDER BY active DESC,id LIMIT 1',(cat,name)).fetchone()
      if existing:
       if (existing['item_type'] or '')!=kind:changed_types+=1
       c.execute('UPDATE products SET price=?,active=1,item_type=? WHERE id=?',(price,kind,existing['id']));updated+=1
      else:
       c.execute('INSERT INTO products(category,name,price,active,item_type) VALUES(?,?,?,1,?)',(cat,name,price,kind));added+=1;new_names.append({'name':name,'category':cat,'item_type':kind})
    return self.send(200,{'ok':True,'added':added,'updated':updated,'changed_types':changed_types,'total':len(cleaned),'new_products':new_names,'message':'Menu catalogue applied. Each product uses the Our/Other type selected in the review table. Past bills were preserved.'})
   if p=='/api/other-inventory/folder':
    name=str(body.get('name','')).strip();parent=body.get('parent_id')
    if not name or len(name)>100:raise ValueError('Folder/subcategory name must be 1–100 characters.')
    parent_id=int(parent) if parent not in (None,'',0,'0') else None
    with db() as c:
     if parent_id and not c.execute('SELECT id FROM other_inventory_folders WHERE id=? AND active=1',(parent_id,)).fetchone():raise ValueError('Parent folder not found.')
     cur=c.execute('INSERT INTO other_inventory_folders(name,parent_id,active) VALUES(?,?,1)',(name,parent_id));fid=cur.lastrowid
    return self.send(200,{'ok':True,'id':fid,'name':name,'parent_id':parent_id})
   if p=='/api/other-inventory/folder/edit':
    fid=int(body.get('id',0));name=str(body.get('name','')).strip()
    if fid<=0 or not name or len(name)>100:raise ValueError('Choose a folder and enter a valid name.')
    with db() as c:
     row=c.execute('SELECT id,name,parent_id FROM other_inventory_folders WHERE id=? AND active=1',(fid,)).fetchone()
     if not row:raise ValueError('Folder not found.')
     old=row['name']
     parent_id=row['parent_id']
     if parent_id is None:
      old_path=old;new_path=name
     else:
      parent=c.execute('SELECT name FROM other_inventory_folders WHERE id=?',(parent_id,)).fetchone()
      old_path=(parent['name']+' / '+old) if parent else old
      new_path=(parent['name']+' / '+name) if parent else name
     c.execute('UPDATE other_inventory_folders SET name=? WHERE id=?',(name,fid))
     if parent_id is None:OTHER_INVENTORY_ROOTS.add(name)
     c.execute("UPDATE products SET category=? || substr(category,?) WHERE item_type='Other Item' AND (category=? OR category LIKE ?)",(new_path,len(old_path)+1,old_path,old_path+' / %'))
    return self.send(200,{'ok':True})
   if p=='/api/other-inventory/folder/delete':
    fid=int(body.get('id',0))
    with db() as c:
     row=c.execute('SELECT id,name,parent_id FROM other_inventory_folders WHERE id=? AND active=1',(fid,)).fetchone()
     if not row:raise ValueError('Folder not found.')
     if c.execute('SELECT 1 FROM other_inventory_folders WHERE parent_id=? AND active=1 LIMIT 1',(fid,)).fetchone():raise ValueError('Remove its subcategories first.')
     prefix=row['name']
     if row['parent_id'] is not None:
      parent=c.execute('SELECT name FROM other_inventory_folders WHERE id=?',(row['parent_id'],)).fetchone()
      if parent:prefix=parent['name']+' / '+prefix
     has_products=c.execute("SELECT 1 FROM products WHERE item_type='Other Item' AND (category=? OR category LIKE ?) AND active=1 LIMIT 1",(prefix,prefix+' / %')).fetchone()
     if has_products:raise ValueError('Remove/deactivate products inside this folder first. Stock and history are protected.')
     c.execute('UPDATE other_inventory_folders SET active=0 WHERE id=?',(fid,))
    return self.send(200,{'ok':True})
   if p=='/api/other-inventory/add':
    try:product_id=int(body.get('product_id',0));qty=int(body.get('quantity',0));mfg=str(body.get('manufacturing_date','')).strip()
    except (TypeError,ValueError):raise ValueError('Choose an Other Item product, manufacturing date, and valid quantity.')
    try:mfg_date=datetime.date.fromisoformat(mfg)
    except ValueError:raise ValueError('Manufacturing date must be YYYY-MM-DD.')
    if mfg_date>datetime.date.today():raise ValueError('Manufacturing date cannot be in the future.')
    if product_id<=0 or qty<1 or qty>100000:raise ValueError('Quantity must be between 1 and 100,000.')
    with db() as c:
     prod=c.execute('SELECT id,name,category,item_type,active FROM products WHERE id=?',(product_id,)).fetchone()
     if not prod or not prod['active'] or not is_inventory_managed_product(prod) or prod['item_type']!='Other Item':raise ValueError('Choose an active product in Puff Pastry, Dry Cakes, Toast or Cookies.')
     created=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
     cur=c.execute('INSERT INTO inventory_batches(product_id,manufacturing_date,qty_received,qty_remaining,created_at) VALUES(?,?,?,?,?)',(product_id,mfg,qty,qty,created));batch_id=cur.lastrowid
     tracked,stock=inventory_status(c,product_id)
    return self.send(200,{'ok':True,'batch_id':batch_id,'product_id':product_id,'product':prod['name'],'category':prod['category'],'manufacturing_date':mfg,'quantity_added':qty,'stock_qty':stock})
   if p=='/api/other-inventory/remove':
    try:batch_id=int(body.get('batch_id',0));qty=int(body.get('quantity',0))
    except (TypeError,ValueError):raise ValueError('Choose a stock batch and quantity.')
    if batch_id<=0 or qty<1:raise ValueError('Quantity to remove must be at least 1.')
    with db() as c:
     batch=c.execute('SELECT b.*,p.name,p.category,p.item_type,p.active FROM inventory_batches b JOIN products p ON p.id=b.product_id WHERE b.id=?',(batch_id,)).fetchone()
     if not batch or batch['item_type']!='Other Item' or not is_inventory_managed_product(batch):raise ValueError('Other Item inventory batch not found.')
     remaining=int(batch['qty_remaining'] or 0)
     if qty>remaining:raise ValueError(f'Only {remaining} unit(s) remain in this batch.')
     c.execute('UPDATE inventory_batches SET qty_remaining=qty_remaining-? WHERE id=?',(qty,batch_id));_,stock=inventory_status(c,int(batch['product_id']))
    return self.send(200,{'ok':True,'removed':qty,'product':batch['name'],'stock_qty':stock})
   if p=='/api/inventory/add':
    try:product_id=int(body.get('product_id',0));qty=int(body.get('quantity',0));mfg=str(body.get('manufacturing_date','')).strip()
    except (TypeError,ValueError):raise ValueError('Choose an Our Item, manufacturing date, and valid quantity.')
    try:mfg_date=datetime.date.fromisoformat(mfg)
    except ValueError:raise ValueError('Manufacturing date must be YYYY-MM-DD.')
    if mfg_date>datetime.date.today():raise ValueError('Manufacturing date cannot be in the future.')
    if product_id<=0 or qty<1 or qty>100000:raise ValueError('Quantity must be between 1 and 100,000.')
    with db() as c:
     prod=c.execute('SELECT id,name,category,item_type,active FROM products WHERE id=?',(product_id,)).fetchone()
     if not prod or not prod['active'] or not is_inventory_managed_product(prod):raise ValueError('Inventory is only for active Our Item products in these categories: Bento Cake, 250 GM Cake, 500 GM Cake, Pastry, Desserts, Cheesecake, and Hot Items.')
     created=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
     cur=c.execute('INSERT INTO inventory_batches(product_id,manufacturing_date,qty_received,qty_remaining,created_at) VALUES(?,?,?,?,?)',(product_id,mfg,qty,qty,created));batch_id=cur.lastrowid
     tracked,stock=inventory_status(c,product_id)
    return self.send(200,{'ok':True,'batch_id':batch_id,'product_id':product_id,'product':prod['name'],'category':prod['category'],'manufacturing_date':mfg,'quantity_added':qty,'stock_qty':stock,'message':'Inventory batch saved. If this item was out of stock, it is available for billing again.'})
   if p=='/api/inventory/remove':
    try:batch_id=int(body.get('batch_id',0));qty=int(body.get('quantity',0))
    except (TypeError,ValueError):raise ValueError('Choose a stock batch and a valid quantity to remove.')
    if batch_id<=0 or qty<1:raise ValueError('Quantity to remove must be at least 1.')
    with db() as c:
     batch=c.execute('SELECT b.*,p.name,p.category,p.item_type,p.active FROM inventory_batches b JOIN products p ON p.id=b.product_id WHERE b.id=?',(batch_id,)).fetchone()
     if not batch or not is_inventory_managed_product(batch):raise ValueError('Inventory batch not found or product is not inventory-managed.')
     remaining=int(batch['qty_remaining'] or 0)
     if qty>remaining:raise ValueError(f'Only {remaining} unit(s) remain in this batch. Sold/consumed stock cannot be removed.')
     c.execute('UPDATE inventory_batches SET qty_remaining=qty_remaining-? WHERE id=?',(qty,batch_id))
     tracked,stock=inventory_status(c,int(batch['product_id']))
    return self.send(200,{'ok':True,'removed':qty,'product':batch['name'],'batch_id':batch_id,'stock_qty':stock,'message':'Unsold stock quantity removed. Previously sold/consumed stock was not changed.'})
   if p=='/api/sales/end-of-day':
    date=str(body.get('date',''))
    try:datetime.date.fromisoformat(date)
    except ValueError:raise ValueError('Choose a valid date in YYYY-MM-DD format.')
    ledger=build_end_of_day_data(date);generated_at=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    with db() as c:
     existing=c.execute('SELECT generated_at FROM daily_closings WHERE sales_date=?',(date,)).fetchone()
     if existing and not body.get('replace',False):return self.send(409,{'error':'A closing already exists for this date. Confirm replacement to regenerate it.'})
     c.execute('INSERT INTO daily_closings(sales_date,generated_at,snapshot_json) VALUES(?,?,?) ON CONFLICT(sales_date) DO UPDATE SET generated_at=excluded.generated_at,snapshot_json=excluded.snapshot_json',(date,generated_at,json.dumps(ledger,ensure_ascii=False)))
    return self.send(200,{'ok':True,'date':date,'generated_at':generated_at,'ledger':ledger,'message':'End of Sales ledger saved. Export is available from this section.'})
   if p=='/api/credit-payment':
    try:bid=int(body.get('bill_id',0));amount=round(float(body.get('amount',0)),2)
    except (TypeError,ValueError):raise ValueError('Enter a valid payment amount.')
    method=str(body.get('method','')).strip()
    if bid<=0 or amount<=0 or not __import__('math').isfinite(amount):raise ValueError('Payment amount must be greater than zero.')
    if method not in ('Cash','Online'):raise ValueError('Choose Cash or Online for received credit payment.')
    with db() as c:
     bill=c.execute("SELECT id,total,credit,payment FROM bills WHERE id=? AND payment IN ('Credit','Split') AND COALESCE(credit,0)>0",(bid,)).fetchone()
     if not bill:raise ValueError('Credit bill not found.')
     paid=float(c.execute('SELECT COALESCE(SUM(amount),0) FROM credit_payments WHERE bill_id=?',(bid,)).fetchone()[0] or 0)
     balance=round(max(0,float(bill['credit'] or bill['total'])-paid),2)
     if balance<=0:raise ValueError('This credit bill is already fully paid.')
     if amount>balance+0.001:raise ValueError(f'Payment exceeds outstanding balance of ₹{balance:.2f}.')
     paid_at=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
     c.execute('INSERT INTO credit_payments(bill_id,paid_at,amount,method,note) VALUES(?,?,?,?,?)',(bid,paid_at,amount,method,str(body.get('note',''))[:200]))
     new_paid=round(paid+amount,2);new_balance=round(max(0,balance-amount),2)
    return self.send(200,{'ok':True,'bill_id':bid,'paid':new_paid,'balance':new_balance,'paid_at':paid_at,'amount':amount,'method':method,'message':'Credit payment recorded.'})
   if p=='/api/zomato-delivery':
    items=body.get('items',[])
    if not isinstance(items,list) or not 1<=len(items)<=100:raise ValueError('Add inventory products to the cart first.')
    normalized=[];product_ids=[]
    for item in items:
     try:pid=int(item.get('id',0));qty=int(item.get('qty',0))
     except (TypeError,ValueError):raise ValueError('Invalid product or quantity in Zomato entry.')
     if pid<=0 or qty<1 or qty>1000:raise ValueError('Invalid product or quantity in Zomato entry.')
     if pid in product_ids:raise ValueError('Duplicate product line. Refresh the cart and try again.')
     product_ids.append(pid);normalized.append({'id':pid,'qty':qty})
    created=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    with db() as c:
     rows={r['id']:r for r in c.execute('SELECT * FROM products WHERE active=1 AND id IN ('+','.join('?' for _ in product_ids)+')',product_ids)}
     if len(rows)!=len(product_ids):raise ValueError('A selected product is no longer available. Refresh the POS and try again.')
     for item in normalized:
      prod=rows[item['id']]
      if not is_inventory_managed_product(prod):raise ValueError(f"{prod['name']} is not part of the managed inventory menu. Only Inventory-section products can be recorded for Zomato.")
      tracked,stock=inventory_status(c,item['id'])
      if not tracked:raise ValueError(f"{prod['name']} has no inventory batch. Add its stock in Inventory before recording Zomato delivery.")
      if stock<item['qty']:raise ValueError(f"Not enough inventory for {prod['name']}. Available: {stock}, requested: {item['qty']}.")
     cur=c.execute("INSERT INTO bills(created,payment,total,cash,online,customer_name,credit,discount_amount) VALUES(?,?,?,?,?,?,?,?)",(created,'Delivered on Zomato',0,0,0,'Zomato Delivery',0,0))
     bid=cur.lastrowid;receipt_items=[]
     for item in normalized:
      prod=rows[item['id']]
      c.execute('INSERT INTO bill_items(bill_id,product,qty,price,item_type,product_id) VALUES(?,?,?,?,?,?)',(bid,prod['name'],item['qty'],0,prod['item_type'],item['id']))
      consume_inventory(c,bid,item['id'],item['qty'])
      receipt_items.append({'name':prod['name'],'qty':item['qty']})
    return self.send(200,{'ok':True,'id':bid,'created':created,'payment':'Delivered on Zomato','total':0,'amount_recorded':False,'items':receipt_items,'message':'Zomato delivery recorded without amount. Inventory quantities deducted.'})
   if p=='/api/checkout':
    items=body.get('items',[]);method=body.get('payment');packing=bool(body.get('packing',False));customer_name=str(body.get('customer_name','')).strip()[:100]
    if not isinstance(items,list) or not 1<=len(items)<=100 or method not in ('Cash','Online','Credit','Split'):raise ValueError('Invalid bill')
    if method=='Credit' and not customer_name:raise ValueError('Customer name is required for credit bills.')
    if method=='Split' and round(float(body.get('credit_split',0) or 0),2)>0 and not customer_name:raise ValueError('Customer name is required when a split bill includes credit.')
    product_ids=[];normalized=[]
    for item in items:
     qty=item.get('qty')
     if not isinstance(qty,int) or not 1<=qty<=1000:raise ValueError('Invalid item quantity')
     if 'custom_type' in item:
      kind=str(item.get('custom_type','')).strip();name=str(item.get('name','')).strip()
      try:price=round(float(item.get('price')),2)
      except (TypeError,ValueError):raise ValueError('Enter a valid price for manual items')
      if kind not in ('Our Item','Other Item') or not name or len(name)>120 or not __import__('math').isfinite(price) or price<=0:raise ValueError('Invalid Our Item / Other Item details')
      source_product_id=item.get('source_product_id')
      if source_product_id not in (None,'',0,'0'):
       try:source_product_id=int(source_product_id)
       except (TypeError,ValueError):raise ValueError('Invalid source product link for this bill item.')
      else:source_product_id=None
      normalized.append({'custom_type':kind,'item_type':kind,'name':name,'price':price,'qty':qty,'source_product_id':source_product_id})
     else:
      if not isinstance(item.get('id'),int):raise ValueError('Invalid product')
      kind=str(item.get('item_type','Our Item')).strip()
      if kind not in ('Our Item','Other Item'):raise ValueError('Choose Our Item or Other Item for each bill item')
      product_ids.append(item['id']);normalized.append({'id':item['id'],'qty':qty,'item_type':kind})
    if len(product_ids)!=len(set(product_ids)):raise ValueError('Duplicate products')
    with db() as c:
     rows={r['id']:r for r in c.execute('SELECT * FROM products WHERE active=1')}
     if any(pid not in rows for pid in product_ids):raise ValueError('A selected product is no longer available. Refresh the POS and try again.')
     for item in normalized:
      linked_pid=item.get('source_product_id') if 'custom_type' in item else None
      if linked_pid is not None and (linked_pid not in rows or rows[linked_pid]['name'].casefold()!=item['name'].casefold()):raise ValueError('A Quick Add bill line no longer matches its saved product. Remove it and add the product again.')
     subtotal=0
     for item in normalized:
      price=item['price'] if 'custom_type' in item else rows[item['id']]['price']
      subtotal+=round(price*item['qty'],2)
      linked_pid=item.get('source_product_id') if 'custom_type' in item else item['id']
      if linked_pid is not None:
       linked=rows.get(linked_pid) if linked_pid in rows else c.execute('SELECT * FROM products WHERE id=? AND active=1',(linked_pid,)).fetchone()
       if not linked:raise ValueError('The product linked to this bill line is no longer available. Refresh POS and retry.')
       if is_inventory_managed_product(linked):
        tracked,stock=inventory_status(c,linked_pid)
        if not tracked:raise ValueError(f"{linked['name']} has no inventory batch. Add stock in Inventory / Other Item Inventory before selling it.")
        if stock<int(item['qty']):raise ValueError(f"Not enough inventory for {linked['name']}. Available: {stock}, requested: {item['qty']}. Add a new inventory batch first.")
     total=round(subtotal,2)
     if total<=0:raise ValueError('Invalid bill total')
     packing_fee=round(float(c.execute("SELECT value FROM settings WHERE key='packing_charge'").fetchone()[0]),2) if packing else 0
     total_before_discount=round(total+packing_fee,2)
     try: discount_amount=round(float(body.get('discount_amount',0) or 0),2)
     except (TypeError,ValueError): raise ValueError('Enter a valid discount amount.')
     if not __import__('math').isfinite(discount_amount) or discount_amount<0: raise ValueError('Discount cannot be negative or invalid.')
     if discount_amount>total_before_discount+0.001: raise ValueError(f'Discount cannot exceed the bill amount {total_before_discount:.2f}.')
     total=round(total_before_discount-discount_amount,2)
     if total<=0: raise ValueError('Discount cannot reduce the bill total to zero. Enter a smaller discount.')
     if method=='Cash':cash,online,credit=total,0.0,0.0
     elif method=='Online':cash,online,credit=0.0,total,0.0
     elif method=='Credit':cash,online,credit=0.0,0.0,total
     else:
      try:
       cash=round(float(body.get('cash',0) or 0),2);online=round(float(body.get('online_split',0) or 0),2);credit=round(float(body.get('credit_split',0) or 0),2)
      except (TypeError,ValueError):raise ValueError('Enter valid Cash, Online and Credit amounts.')
      if any(not __import__('math').isfinite(v) or v<0 for v in (cash,online,credit)):raise ValueError('Split amounts cannot be negative or invalid.')
      if abs(round(cash+online+credit,2)-total)>0.01:raise ValueError(f'Cash + Online + Credit must equal the bill total ₹{total:.2f}.')
      if credit>0 and not customer_name:raise ValueError('Customer name is required when credit is included.')
     created=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
     cur=c.execute('INSERT INTO bills(created,payment,total,cash,online,customer_name,credit,discount_amount) VALUES(?,?,?,?,?,?,?,?)',(created,method,total,cash,online,customer_name,credit,discount_amount));bid=cur.lastrowid
     receipt_items=[]
     for item in normalized:
      if 'custom_type' in item:
       name=item['name'];price=item['price'];label=item['item_type']+' - '+name
      else:
       r=rows[item['id']];name=r['name'];price=r['price'];label=item['item_type']+' - '+r['name']
      product_id=(item.get('source_product_id') if 'custom_type' in item else int(item['id']))
      c.execute('INSERT INTO bill_items(bill_id,product,qty,price,item_type,product_id) VALUES(?,?,?,?,?,?)',(bid,name,item['qty'],price,item.get('item_type','Our Item'),product_id))
      if product_id is not None:consume_inventory(c,bid,product_id,item['qty'])
      receipt_items.append({'name':name,'qty':item['qty'],'price':price,'type':item.get('item_type','Our Item')})
    return self.send(200,{'id':bid,'created':created,'total':total,'cash':cash,'online':online,'payment':method,'customer_name':customer_name,'credit':credit,'packing_fee':packing_fee,'discount_amount':discount_amount,'items':receipt_items})
   if p=='/api/bill/delete':
    bid=int(body.get('bill_id',0))
    if bid<=0:raise ValueError('Invalid bill ID')
    with db() as c:
     found=c.execute('SELECT id FROM bills WHERE id=?',(bid,)).fetchone()
     if not found:raise ValueError('Bill not found; it may already have been removed.')
     restore_bill_inventory(c,bid)
     c.execute('DELETE FROM bill_items WHERE bill_id=?',(bid,))
     c.execute('DELETE FROM bills WHERE id=?',(bid,))
    return self.send(200,{'ok':True,'deleted':bid,'message':'Bill and its item rows removed. Dashboard totals and future exports will reflect the removal.'})
   if p=='/api/bill/update':
    bid=int(body.get('bill_id',0));items=body.get('items',[]);method=body.get('payment')
    if bid<=0 or not isinstance(items,list) or not 1<=len(items)<=100:raise ValueError('A bill must contain 1 to 100 items.')
    if method not in ('Cash','Online','Split'):raise ValueError('Choose Cash, Online or Split payment.')
    clean=[]
    for it in items:
     name=str(it.get('name','')).strip();kind=str(it.get('item_type','Our Item')).strip()
     try:qty=int(it.get('qty'));price=round(float(it.get('price')),2);product_id=int(it.get('product_id')) if it.get('product_id') not in (None,'','0',0) else None
     except (TypeError,ValueError):raise ValueError('Check item quantity, product link and price.')
     if not name or len(name)>150 or kind not in ('Our Item','Other Item') or qty<1 or qty>1000 or not __import__('math').isfinite(price) or price<0 or price>1000000:raise ValueError('Invalid item name, type, quantity or price.')
     clean.append((name,qty,price,kind,product_id))
    with db() as c:
     old=c.execute('SELECT * FROM bills WHERE id=?',(bid,)).fetchone()
     if not old:raise ValueError('Bill not found; refresh Recent Bills.')
     old_items=c.execute('SELECT qty,price FROM bill_items WHERE bill_id=?',(bid,)).fetchall()
     old_item_sum=sum(int(x['qty'])*float(x['price']) for x in old_items)
     restore_bill_inventory(c,bid)
     # Preserve the difference between old bill total and item lines (e.g. packing charge) during edits.
     adjustment=max(0,round(float(old['total'])-old_item_sum,2))
     new_item_sum=round(sum(qty*price for _,qty,price,_,_ in clean),2)
     total=round(new_item_sum+adjustment,2)
     cash=total if method=='Cash' else 0.0 if method=='Online' else round(float(body.get('cash',old['cash'])),2)
     if not __import__('math').isfinite(cash) or not 0<=cash<=total:raise ValueError('Cash amount must be between ₹0 and bill total.')
     online=round(total-cash,2)
     c.execute('DELETE FROM bill_items WHERE bill_id=?',(bid,))
     for name,qty,price,kind,product_id in clean:
      if product_id is not None:
       prod=c.execute('SELECT name,active,item_type,category FROM products WHERE id=?',(product_id,)).fetchone()
       if not prod or not prod['active'] or prod['name']!=name:raise ValueError('A linked product changed or was removed. Reopen Recent Bills and try again.')
       if is_inventory_managed_product(prod):
        tracked,stock=inventory_status(c,product_id)
        if tracked and stock<qty:raise ValueError(f"Not enough inventory for {name}. Available: {stock}, requested: {qty}. Add a new inventory batch first.")
      c.execute('INSERT INTO bill_items(bill_id,product,qty,price,item_type,product_id) VALUES(?,?,?,?,?,?)',(bid,name,qty,price,kind,product_id))
      if product_id is not None:consume_inventory(c,bid,product_id,qty)
     c.execute('UPDATE bills SET payment=?,total=?,cash=?,online=? WHERE id=?',(method,total,cash,online,bid))
     updated=dict(c.execute('SELECT * FROM bills WHERE id=?',(bid,)).fetchone())
    return self.send(200,{'ok':True,'bill':updated,'message':'Bill updated. Historical bill timestamp preserved; reports and exports now use updated values.'})
   if p=='/api/settings':
    fee=float(body.get('packing_charge',-1))
    if not 0<=fee<=10000 or not __import__('math').isfinite(fee):raise ValueError('Invalid packing charge')
    with db() as c:c.execute("UPDATE settings SET value=? WHERE key='packing_charge'",(str(round(fee,2)),))
    return self.send(200,{'ok':True,'packing_charge':fee})
   if p=='/api/product/delete':
    pid=int(body.get('id',0))
    with db() as c:
     c.execute('UPDATE products SET active=0 WHERE id=?',(pid,))
    return self.send(200,{'ok':True})
   if p=='/api/category/delete':
    cat=str(body.get('category','')).strip()
    if not cat:raise ValueError('Choose a category to delete')
    with db() as c:
     cur=c.execute('UPDATE products SET active=0 WHERE category=? AND active=1',(cat,))
     count=cur.rowcount
     if not count:raise ValueError('No active items found in this category')
    return self.send(200,{'ok':True,'deactivated':count,'message':'Category and its active items were removed from the current product list. Past bills remain unchanged.'})
   if p=='/api/category/rename':
    old=str(body.get('old','')).strip();new=str(body.get('new','')).strip()
    if not old or not new or len(new)>100:raise ValueError('Invalid category')
    with db() as c:
     for r in c.execute('SELECT id,name FROM products WHERE category=?',(old,)).fetchall():
      conflict=c.execute('SELECT 1 FROM products WHERE category=? AND name=? AND id!=?',(new,r['name'],r['id'])).fetchone()
      if conflict:raise ValueError('Product name already exists in target category: '+r['name'])
     c.execute('UPDATE products SET category=? WHERE category=?',(new,old))
    return self.send(200,{'ok':True})
   if p=='/api/product/prices':
    prices=body.get('prices',[])
    if not isinstance(prices,list) or not 1<=len(prices)<=5000:raise ValueError('Invalid product price update list.')
    cleaned=[]
    for row in prices:
     try:pid=int(row.get('id'));price=round(float(row.get('price')),2)
     except (TypeError,ValueError):raise ValueError('Each product must have a valid price.')
     if not __import__('math').isfinite(price) or not 0<=price<=1000000:raise ValueError('Prices must be between ₹0 and ₹10,00,000.')
     cleaned.append((price,pid))
    with db() as c:
     for price,pid in cleaned:
      cur=c.execute('UPDATE products SET price=? WHERE id=? AND active=1',(price,pid))
      if cur.rowcount!=1:raise ValueError('A product is no longer available. Refresh and try again.')
    return self.send(200,{'ok':True,'updated':len(cleaned),'message':'Product prices saved. Past bill prices remain unchanged.'})
   if p=='/api/quick-add-product':
    cat=str(body.get('category','Quick Added')).strip()[:100];name=str(body.get('name','')).strip()[:150];kind=str(body.get('item_type','')).strip()
    try:price=round(float(body.get('price',-1)),2)
    except (TypeError,ValueError):raise ValueError('Enter a valid product price.')
    if not cat or not name or not __import__('math').isfinite(price) or not 0<price<=1000000:raise ValueError('Enter a category, product name, and price greater than ₹0 up to ₹10,00,000.')
    if kind not in ('Our Item','Other Item'):raise ValueError('Choose whether the new product is Our Item or Other Item.')
    with db() as c:
     existing=c.execute('SELECT id,category,name,price,active,item_type FROM products WHERE lower(trim(category))=lower(trim(?)) AND lower(trim(name))=lower(trim(?)) ORDER BY active DESC,id LIMIT 1',(cat,name)).fetchone()
     if existing:
      c.execute('UPDATE products SET active=1 WHERE id=?',(existing['id'],))
      return self.send(200,{'ok':True,'created':False,'id':existing['id'],'category':existing['category'],'name':existing['name'],'price':float(existing['price']),'item_type':existing['item_type'] or 'Our Item','message':'Product already existed; saved price and ledger classification retained.'})
     cur=c.execute('INSERT INTO products(category,name,price,active,item_type) VALUES(?,?,?,1,?)',(cat,name,price,kind));pid=cur.lastrowid
    return self.send(200,{'ok':True,'created':True,'id':pid,'category':cat,'name':name,'price':price,'item_type':kind,'message':'Product, category, and ledger classification saved.'})
   if p=='/api/product':
    cat=str(body.get('category','')).strip();name=str(body.get('name','')).strip()
    try:price=float(body.get('price',-1))
    except (TypeError,ValueError):raise ValueError('Enter a valid selling price.')
    pid=body.get('id');kind=str(body.get('item_type','')).strip()
    if not cat or not name or len(cat)>100 or len(name)>150 or not __import__('math').isfinite(price) or not 0<=price<=1000000:raise ValueError('Enter a valid category, product name and price.')
    if kind not in ('Our Item','Other Item'):raise ValueError('Choose whether this product is Our Item or Other Item before saving.')
    with db() as c:
     if kind=='Other Item':
      root=re.split(r'\s*(?:/|›|>)\s*', cat, maxsplit=1)[0].strip()
      if category_key(root) not in {category_key(x) for x in OTHER_INVENTORY_ROOTS}:raise ValueError('Choose a product category inside Puff Pastry, Dry Cakes, Toast or Cookies.')
     duplicate=c.execute('SELECT id FROM products WHERE lower(trim(category))=lower(trim(?)) AND lower(trim(name))=lower(trim(?)) AND active=1 AND (? IS NULL OR id<>?) LIMIT 1',(cat,name,int(pid) if pid not in (None,'','0',0) else None,int(pid) if pid not in (None,'','0',0) else None)).fetchone()
     if duplicate:raise ValueError('A product with this name already exists in this category. Edit the existing product instead.')
     if pid:
      cur=c.execute('UPDATE products SET category=?,name=?,price=?,active=1,item_type=? WHERE id=?',(cat,name,price,kind,int(pid)))
      if cur.rowcount==0:raise ValueError('Product not found. Refresh the page and try again.')
      product_id=int(pid)
     else:
      cur=c.execute('INSERT INTO products(category,name,price,active,item_type) VALUES(?,?,?,1,?)',(cat,name,price,kind));product_id=cur.lastrowid
    return self.send(200,{'ok':True,'id':product_id,'category':cat,'name':name,'price':price,'item_type':kind})
   return self.send(404,{'error':'Not found'})
  except Exception as e:return self.send(400,{'error':str(e)})
if __name__=='__main__':
 port=int(os.environ.get('TCS_POS_PORT','8765'));host='0.0.0.0';server=ThreadingHTTPServer((host,port),Handler)
 print('\nTHE CREAM STUDIO POS V61\nLaptop: http://localhost:%d/?token=%s\n'%(port,TOKEN));
 try:
  ip=socket.gethostbyname(socket.gethostname());print('Mobile (same Wi-Fi): http://%s:%d/?token=%s'%(ip,port,TOKEN))
 except Exception:pass
 print('Keep this window running. Do not share the token or expose port 8765 to the internet.\n')
 threading.Timer(1,lambda:webbrowser.open('http://localhost:%d/?token=%s'%(port,TOKEN))).start();server.serve_forever()
